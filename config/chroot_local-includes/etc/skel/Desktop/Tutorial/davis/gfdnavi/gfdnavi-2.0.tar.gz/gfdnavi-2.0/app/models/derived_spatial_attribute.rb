class DerivedSpatialAttribute < ActiveRecord::Base
  
end
