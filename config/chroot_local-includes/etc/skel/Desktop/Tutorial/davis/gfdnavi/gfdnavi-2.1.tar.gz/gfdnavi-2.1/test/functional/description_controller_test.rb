require File.dirname(__FILE__) + '/../test_helper'
require 'description_controller'

# Re-raise errors caught by the controller.
class DescriptionController; def rescue_action(e) raise e end; end

class DescriptionControllerTest < Test::Unit::TestCase
  def setup
    @controller = DescriptionController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
