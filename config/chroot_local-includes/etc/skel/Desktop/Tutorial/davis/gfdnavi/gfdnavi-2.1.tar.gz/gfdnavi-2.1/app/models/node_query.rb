require "activerecord_gfdnavi"

class NodeQuery
 
 def make_query(descriptions,user) #�����̏ꍇ����
   flag=0
   results = Hash.new
   options=Array.new(0)
   @spregion=[10,-80,350,80]
#debugger
   if descriptions.size==1 && descriptions[0]=="all" then
     return "all"
   end

   descriptions.each{ |desc|
=begin   
     if desc == "all"
       #allqstr = "select * from nodes;"
       allqstr="all"
       return allqstr
     end
=end     
       if desc=~/(.*)=(.*)/ then

        case $1
        when "fw"
         options.push(get_condition4fw(desc))
      	when "tm"
		 options.push(get_condition4time(desc))
        when "path"
         options.push(get_condition4path(desc))
        when "datatype"
	     options.push(get_condition4nodetype(desc))
        when "kw"
         options.push(get_condition4kwname(desc))
        when if $1=~/(.*)\./ then
              case $1      
              when "kw"
                 options.push(get_condition4kw(desc))
              else
                 options=Array.new(0)
                 break
              end
	    end
        end
         
       elsif desc=~/(.*)\[.*\]/ then
         case $1
           when "sp.overlap"
         
            o=get_condition4space(desc)
            options.push(o)
            @spregion=o[:spregion]
           else
             options=Array.new(0)
             break
           end
      end
   }
 
   if options==Array.new(0) then
     return 
   elsif options then     
     allqstr = generate_querystring(options,user)
     return allqstr
   end
 end

 def generate_results(rnodes,expres,options)
   limit = 100
   if options[:limit]!=nil then
     limit = options[:limit].to_i
   end
   offset = 0
   if options[:offset]!=nil then
     offset = options[:offset].to_i
   end
     
   result_nodes=Array.new
   lcnt=0
   ocnt=0

   results = Hash.new     

   #show keyword facet
   if options["show_kwfacets"].to_i==1 then
     if options["show_kwvalues"].to_i==1 then
       keyname="-"
       kcnt=-1
       keyvalues=Array.new
       keylist = expres.get_keyname_and_keyvalue_list
       if keylist!=nil then
         keywords = Array.new
         keylist.each{ |kl|
           #if kl.kname == $qname then
             if keyname.downcase!=kl.kname.downcase then 
               # if kl.kname == $qname then
               if kcnt>-1 then
                 keycount = Hash.new
                 keycount[:keyname]=keyname
                 keycount[:count]=kcnt
                 keycount[:keyvalues]=keyvalues
                 keywords.push(keycount)
               end
               # end
               keyvalues=Array.new
               if kl.cnt then
                 kcnt=kl.cnt.to_i
               else
                 kcnt=0
               end
               keyname=kl.kname
             else
               if kl.cnt then
                 kcnt=kcnt+kl.cnt.to_i
               end
             end
             
             kvalue=Hash.new
             kvalue[:keyvalue]=kl.kvalue
             if kl.cnt then
               kvalue[:count]=kl.cnt.to_i
             else
               kvalue[:count]=0            
             end
             keyvalues.push(kvalue)
           #end
         }
         
         keycount = Hash.new
         keycount[:keyname]=keyname
         keycount[:count]=kcnt
         keycount[:keyvalues]=keyvalues
         keywords.push(keycount)
         keywords.reverse!{|a,b|
           a[:count].to_i<=>b[:count].to_i
         }
         results["keywords"]=keywords
       end
       
     else
       keylist = expres.get_keyname_list
       if keylist!=nil then
         keywords = Array.new
         keylist.each{ |kl|
           keycount = Hash.new
           keycount[:keyname]=kl.kname
           keycount[:count]=kl.cnt
           keywords.push(keycount)
         }
         results["keywords"]=keywords
       end
     end
   end 
   
   #show spatial facet
   if options["show_spfacets"].to_i==1 then
   
     spfacets=Hash.new
     results[:spatial_attributes]=spfacets
     points=Array.new
     spfacets[:points]=points
     expres.points(@spregion[0],@spregion[1],@spregion[2],@spregion[3]).each{|p|
       pnt=Hash.new
       pnt[:latitude_lb]=p.latitude_lb
   
       pnt[:longitude_lb]=p.longitude_lb
       pnt[:latitude_rt]=p.latitude_rt
       pnt[:longitude_rt]=p.longitude_rt
       pnt[:count]=p.cnt
       points.push(pnt)
     }
     partial_covered_regions=Array.new
     spfacets[:partial_covered]=partial_covered_regions
     expres.partial_covered(@spregion[0],@spregion[1],@spregion[2],@spregion[3]).each{|p|
       rgn=Hash.new
       rgn[:latitude_lb]=p.latitude_lb
       rgn[:longitude_lb]=p.longitude_lb
       rgn[:latitude_rt]=p.latitude_rt
       rgn[:longitude_rt]=p.longitude_rt
       rgn[:count]=p.cnt
       partial_covered_regions.push(rgn)
     }
     all_covered_regions=Array.new
     spfacets[:all_covered]=all_covered_regions
     expres.all_covered(@spregion[0],@spregion[1],@spregion[2],@spregion[3]).each{|p|
       rgn=Hash.new
       rgn[:latitude_lb]=p.latitude_lb
       rgn[:longitude_lb]=p.longitude_lb
       rgn[:latitude_rt]=p.latitude_rt
       rgn[:longitude_rt]=p.longitude_rt
       rgn[:count]=p.cnt
       all_covered_regions.push(rgn)
     }
   end 
   if options["show_pathtree"].to_i==1 then
     pt_ent=15 #����15�Ƃ��� @debug 2010-07-21
     results["pathtree"]=generate_pathtree(rnodes,pt_ent) 
   end
   
   return results
  end

 def generate_results_fromtmptable(isInitial,tmptable,options,user)
     
   results = Hash.new
   @spregion=[10,-80,350,80]

   #show keyword facet
   if options["show_kwfacets"].to_i==1 then
     if options["show_kwvalues"].to_i==1 then     
       keylist = CrossResult.get_keyname_list_fromtmptable(isInitial,tmptable,user)
       if keylist!=nil then
         keywords = Hash.new
         keylist.each{ |kl|
           keycount = Hash.new
           keycount[:keyname]=kl.kname
           keycount[:count]=kl.cnt
           keycount[:keyvalues]=Array.new
           keywords[kl.kname]=keycount
#           puts keycount.to_s
#           puts "============================="
         }
       else
         return
       end     
=begin       
       puts "----------------------------------"
       puts keywords.to_s
       puts "----------------------------------"
=end
       keylist = CrossResult.get_keyname_and_keyvalue_list_fromtmptable(isInitial,tmptable,user)
       if keylist!=nil then
         keylist.each{ |kl|
         	kvalue=Hash.new
         	kvalue[:keyvalue]=kl.kvalue
         	if kl.cnt then
         	  kvalue[:count]=kl.cnt.to_i
         	else
              kvalue[:count]=0
            end      
            kname=kl.kname
         	keywords[kname][:keyvalues].push(kvalue)
         }
       end
       keywords_array=keywords.values  
       keywords_array.reverse!{|a,b|
         a[:count].to_i<=>b[:count].to_i
       }
       results[:keywords]=keywords_array
     else
       keylist = CrossResult.get_keyname_list_fromtmptable(isInitial,tmptable,user)
       if keylist!=nil then
         keywords = Array.new
         keylist.each{ |kl|
           keycount = Hash.new
           keycount[:keyname]=kl.kname
           keycount[:count]=kl.cnt
           keywords.push(keycount)
         }
         results["keywords"]=keywords
       end
     end
   end 
   
   #show spatial facet
   if options["show_spfacets"].to_i==1 then
   
     spfacets=Hash.new
     results[:spatial_attributes]=spfacets
     points=Array.new
     spfacets[:points]=points
     CrossResult.points_fromtmptable(isInitial,tmptable,@spregion[0],@spregion[1],@spregion[2],@spregion[3],user).each{|p|
       pnt=Hash.new
       pnt[:latitude_lb]=p.latitude_lb   
       pnt[:longitude_lb]=p.longitude_lb
       pnt[:latitude_rt]=p.latitude_rt
       pnt[:longitude_rt]=p.longitude_rt
       pnt[:count]=p.cnt
       points.push(pnt)
     }
     partial_covered_regions=Array.new
     spfacets[:partial_covered]=partial_covered_regions
     CrossResult.partial_covered_fromtmptable(isInitial,tmptable,@spregion[0],@spregion[1],@spregion[2],@spregion[3],user).each{|p|
       rgn=Hash.new
       rgn[:latitude_lb]=p.latitude_lb
       rgn[:longitude_lb]=p.longitude_lb
       rgn[:latitude_rt]=p.latitude_rt
       rgn[:longitude_rt]=p.longitude_rt
       rgn[:count]=p.cnt
       partial_covered_regions.push(rgn)
     }
     all_covered_regions=Array.new
     spfacets[:all_covered]=all_covered_regions
     CrossResult.all_covered_fromtmptable(isInitial,tmptable,@spregion[0],@spregion[1],@spregion[2],@spregion[3],user).each{|p|
       rgn=Hash.new
       rgn[:latitude_lb]=p.latitude_lb
       rgn[:longitude_lb]=p.longitude_lb
       rgn[:latitude_rt]=p.latitude_rt
       rgn[:longitude_rt]=p.longitude_rt
       rgn[:count]=p.cnt
       all_covered_regions.push(rgn)
     }
   end 
   if options["show_pathtree"].to_i==1 then
     pt_ent=15 #����15�Ƃ��� @debug 2010-07-21
     res = generate_pathtree_fromtmptable(isInitial,tmptable,pt_ent,user) 
     if res!=nil then
       results["pathtree"]=res
     end
   end   
   return results
  end

 
 def generate_pathtree(nodes,pt_ent)
   pathtree=Hash.new
   pathtree[:name]="/"
   pathtree[:count]=0
   pathtree[:path]="/"
   nodes.each{ |n|
     nd=Hash.new
     nd[:path]=n.path
     nd[:id]=n.id
     nd[:node_type]=n.node_type
     cur=pathtree
     path=""
     depth=n.path.split(/\//).size
     dcount=0
     n.path.split(/\//).each{ |name|
       dcount=dcount+1
       if name=='' then
         cur[:count]=cur[:count]+1
         path="/"
         next
       else
         path="#{path}#{name}/"
       end
       if dcount==depth then
         break
       end
       flg=0
       if cur.key?(:directories) then
         cur[:directories].each{ |c|
           if c[:name]==name then
             c[:count]=c[:count]+1
             cur=c
             flg=1
             next
           end
         }
       else
         cur[:directories]=Array.new
       end
       if flg==0 then
         dir=Hash.new
         dir[:name]=name
         dir[:path]=path
         dir[:count]=1
         cur[:directories].push(dir)
         cur=dir
       end
     }
     if !cur.key?(:objects) then
       cur[:objects]=Array.new
     end
     cur[:objects].push(nd)
     
   }
   #p pathtree
   stack=Array.new
   # save the depth of the root node (pending)
   #pathtree[:depth]=0
   stack.push(pathtree)

   while stack.size>0 do
     cur=stack.pop
     # get the node depth
     curdepth=cur[:depth]
     if cur.key?(:directories) && cur[:directories].size==1 then
       dir=cur[:directories][0]
       #merge name
       if cur[:name]!="/" then
         cur[:name]="#{cur[:name]}/#{dir[:name]}"
       else
           cur[:name]="#{cur[:name]}#{dir[:name]}"
       end
       #update path
       cur[:path]=dir[:path]
       #update count
       cur[:count]=dir[:count]
       #merge objects
       if dir.key?(:objects) then
         if !cur.key?(:objects) then
           cur[:objects]=Array.new
         end
           dir[:objects].each{ |o|
           cur[:objects].push(o)
         }
       end
       #merge directories
         cur[:directories].clear
       if dir.key?(:directories) then
         dir[:directories].each{ |d|
           cur[:directories].push(d)
           # save the node depth just before pushing it to stack(pending)
           #d[:depth]=curdepth+1
           #stack.push(d)
         }
         stack.push(cur)
       else
           cur.delete(:directories)
       end
     elsif cur.key?(:directories) then
       cur[:directories].each{ |dir|
         # save the node depth just before pushing it to stack(pending)
         #dir[:depth]=curdepth+1
         stack.push(dir)
       }
     end
   end
   
   #�Ԃ��m�[�h�̃G���g������pt_ent�Ɍ��肷��
   cnt=0
   queue=Array.new
   queue.push(pathtree)
   while queue.size > 0 do
    cur=queue.shift
    if cur.key?(:directories) then #�q�m�[�h������
      cur[:leaf]=0 #���[�t�m�[�h�ł͂Ȃ�
      #cur�̎q�m�[�h���������pt_ent�𒴂��Ă��܂��ꍇ
      #cur�̎q�m�[�h���폜���Ă��܂�
      if cnt+cur[:directories].size>pt_ent then
        cur.delete(:directories)
        cur[:treeicon]="plus"
      else
        #�����Ȃ��ꍇ��cur�̎q�m�[�h��queue�ɒǉ�
        cnt=cnt+cur[:directories].size        
        cur[:directories].each{ |d|
          queue.push(d)
        }
        cur[:treeicon]="minus"
      end
    else
      cur[:leaf]=1 #���[�t�m�[�h�ł���      
    end    
    if cur.key?(:objects) then
      cur[:hasobj]=1 #�I�u�W�F�N�g������
      #object���������pt_ent�𒴂��Ă��܂��ꍇ
      if cnt+cur[:objects].size>pt_ent then
        #cur�̎q�m�[�h���폜
        cur.delete(:objects)
        cur[:treeicon]="plus"
      else
        #�����Ȃ��ꍇ�̓I�u�W�F�N�g��ǉ�
        cnt=cnt+cur[:objects].size
        cur[:treeicon]="minus"
      end
    else
      cur[:hasobj]=0 #�I�u�W�F�N�g�������ĂȂ�
    end
   end
   
   return pathtree
 end

 def generate_pathtree_fromtmptable(isInitial,tmptable,pt_ent,user)
   pathtree=Hash.new
   pathtree[:name]="/"
   pathtree[:count]=0
   pathtree[:path]="/"
   
   if isInitial==0 then
    qstr=<<-EOM
      select n.id,n.path,n.node_type
      from nodes n join #{tmptable} t on n.id=t.id
    EOM
   else
    return generate_initial_pathtree(pt_ent,user)
   end   
   access_conditions=Node.conditions_to_read(user)
   if access_conditions!=nil then
     qstr+="where "+access_conditions+" and n.node_type!=0"
   else
     qstr+="where n.node_type!=0"
   end
   nodes=Node.find_by_sql(qstr)
   
   #���ʂ�0��������null��Ԃ�
   if nodes.size==0 then 
     return nil
   end
   
   nodes.each{ |n|
     nd=Hash.new
     nd[:path]=n.path
     nd[:id]=n.id
     nd[:node_type]=n.node_type
     cur=pathtree
     path=""
     depth=n.path.split(/\//).size
     dcount=0
     n.path.split(/\//).each{ |name|
       dcount=dcount+1
       if name=='' then
         cur[:count]=cur[:count]+1
         path="/"
         next
       else
         path="#{path}#{name}/"
       end
       if dcount==depth then
         break
       end
       flg=0
       if cur.key?(:directories) then
         cur[:directories].each{ |c|
           if c[:name]==name then
             c[:count]=c[:count]+1
             cur=c
             flg=1
             next
           end
         }
       else
         cur[:directories]=Array.new
       end
       if flg==0 then
         dir=Hash.new
         dir[:name]=name
         dir[:path]=path
         dir[:count]=1
         cur[:directories].push(dir)
         cur=dir
       end
     }
     if !cur.key?(:objects) then
       cur[:objects]=Array.new
     end
     cur[:objects].push(nd)
     
   }
   #p pathtree
   stack=Array.new
   # save the depth of the root node (pending)
   #pathtree[:depth]=0
   stack.push(pathtree)

   while stack.size>0 do
     cur=stack.pop
     # get the node depth
     curdepth=cur[:depth]
     if cur.key?(:directories) && cur[:directories].size==1 then
       dir=cur[:directories][0]
       #merge name
       if cur[:name]!="/" then
         cur[:name]="#{cur[:name]}/#{dir[:name]}"
       else
           cur[:name]="#{cur[:name]}#{dir[:name]}"
       end
       #update path
       cur[:path]=dir[:path]
       #update count
       cur[:count]=dir[:count]
       #merge objects
       if dir.key?(:objects) then
         if !cur.key?(:objects) then
           cur[:objects]=Array.new
         end
         dir[:objects].each{ |o|
           cur[:objects].push(o)
         }
       end
       #merge directories
         cur[:directories].clear
       if dir.key?(:directories) then
         dir[:directories].each{ |d|
           cur[:directories].push(d)
           # save the node depth just before pushing it to stack(pending)
           #d[:depth]=curdepth+1
           #stack.push(d)
         }
         stack.push(cur)
       else
           cur.delete(:directories)
       end
     elsif cur.key?(:directories) then
       cur[:directories].each{ |dir|
         # save the node depth just before pushing it to stack(pending)
         #dir[:depth]=curdepth+1
         stack.push(dir)
       }
     end
   end
   
   #�Ԃ��m�[�h�̃G���g������pt_ent�Ɍ��肷��
   cnt=0
   queue=Array.new
   queue.push(pathtree)
   while queue.size > 0 do
    cur=queue.shift
    if cur.key?(:directories) then #�q�m�[�h������
      cur[:leaf]=0 #���[�t�m�[�h�ł͂Ȃ�
      #cur�̎q�m�[�h���������pt_ent�𒴂��Ă��܂��ꍇ
      #cur�̎q�m�[�h���폜���Ă��܂�
      if cnt+cur[:directories].size>pt_ent then
        cur.delete(:directories)
        cur[:treeicon]="plus"
      else
        #�����Ȃ��ꍇ��cur�̎q�m�[�h��queue�ɒǉ�
        cnt=cnt+cur[:directories].size        
        cur[:directories].each{ |d|
          queue.push(d)
        }
        cur[:treeicon]="minus"
      end
    else
      cur[:leaf]=1 #���[�t�m�[�h�ł���      
    end    
    if cur.key?(:objects) then
      cur[:hasobj]=1 #�I�u�W�F�N�g������
      #object���������pt_ent�𒴂��Ă��܂��ꍇ
      if cnt+cur[:objects].size>pt_ent then
        #cur�̎q�m�[�h���폜
        cur.delete(:objects)
        cur[:treeicon]="plus"
      else
        #�����Ȃ��ꍇ�̓I�u�W�F�N�g��ǉ�
        cnt=cnt+cur[:objects].size
        cur[:treeicon]="minus"
      end
    else
      cur[:hasobj]=0 #�I�u�W�F�N�g�������ĂȂ�
    end
   end
   return pathtree
 end
 
 def generate_initial_pathtree(pt_ent,user)
   
   access_conditions=Node.conditions_to_read(user,"n1.")
   if access_conditions!=nil then
     n1_ac="and "+access_conditions
     n2_ac="and "+Node.conditions_to_read(user,"n2.")
   else
     n1_ac=""
     n2_ac=""
   end 
   qstr=<<-EOM
    select n2.id as id,n2.path as path,n2.node_type as node_type,count(distinct l2.id) as cnt
    from nodes n1, node_lineages l1,
         nodes n2, node_lineages l2,
         nodes n3
    where n1.id=l1.ancestor
      and n2.id=l1.descendant
      and n2.id=l2.ancestor
      and n3.id=l2.descendant
      and n2.node_type=0
      and n1.path="/"
      #{n1_ac} #{n2_ac}
      and l2.rel_depth>0
      and l1.rel_depth<4
      and n3.node_type!=0
      group by n2.id,n2.path,n2.node_type
      order by n2.path
    EOM
        
   nodes=Node.find_by_sql(qstr)   
   #���ʂ�0��������null��Ԃ�
   if nodes.size==0 then 
     return nil
   end
      
   pathtree=Hash.new
   pathtree[:name]="/"
   pathtree[:count]=0
   pathtree[:path]="/"
   
   nodes.each{ |n|
     nd=Hash.new
     nd[:path]=n.path
     nd[:id]=n.id
     nd[:node_type]=n.node_type
     nd[:count]=n.cnt.to_i
     cur=pathtree
     path=""
     depth=n.path.split(/\//).size
     dcount=0
     n.path.split(/\//).each{ |name|
       dcount=dcount+1
       if name=='' then       
         #cur[:count]=cur[:count]+nd[:count]
         path="/"
         next
       else
         path="#{path}#{name}/"
       end
       if dcount==depth then
         cur[:count]=nd[:count]
         break
       end
       flg=0
       if cur.key?(:directories) then
         cur[:directories].each{ |c|
           if c[:name]==name then
             cur=c
             flg=1
             next
           end
         }
       else
         cur[:directories]=Array.new
       end
       if flg==0 then
         dir=Hash.new
         dir[:name]=name
         dir[:path]=path
         #dir[:count]=nd[:count]
         cur[:directories].push(dir)
         cur=dir
       end
     }
=begin
     if !cur.key?(:objects) then
       cur[:objects]=Array.new
     end
     cur[:objects].push(nd)     
=end
   }

   cnt=0
   queue=Array.new
   queue.push(pathtree)
   while queue.size > 0 do
    cur=queue.shift
    cur[:leaf]=0 
    if cur.key?(:directories) then #�q�m�[�h������
        cnt=cnt+cur[:directories].size        
        cur[:directories].each{ |d|
          queue.push(d)
        }
        cur[:treeicon]="minus"
    else
      cur[:treeicon]="plus"
    end    
   end
   
   return pathtree
   
 end


 def generate_querystring(options,user)
      cnt=0
      sptmky=Array.new
      sptm_qstr_conditions=Array.new
      node_qstr_conditions=Array.new
     
      options.each{ |qh|
        if qh[:querytype] == "keyword" || qh[:querytype]=="keyname" || qh[:querytype] == "freeword" then
          qstr=<<-EOM
            select r.descendant as nid, 'k#{cnt}' as qno, r.rel_depth as relevance
            from keyword_attributes k join node_lineages r on k.node_id = r.ancestor
            where #{qh[:cond]}
          EOM
          sptmky.push(qstr)
          if qh[:querytype] == "freeword" then
            qh[:cond] =~/name like (.*) or/            
            qstr=<<-EOM
              select r.descendant as nid, 'k#{cnt}' as qno, r.rel_depth as relevance
              from nodes n join node_lineages r on n.id = r.ancestor
              where name like #{$1}
            EOM
            sptmky.push(qstr)
          end	
          cnt=cnt+1         
        elsif qh[:querytype]=="space" || qh[:querytype]== "time" then
     	  sptm_qstr_conditions.push(qh[:cond])
        elsif qh[:querytype]=="path" then
          nodepath_qstr=<<-EOM
             select r.descendant as nid, 'np' as qno, r.rel_depth as relevance
             from nodes n join node_lineages r on n.id = r.ancestor
             where #{qh[:cond]}          
          EOM
          sptmky.push(nodepath_qstr)
          cnt=cnt+1
        elsif qh[:querytype]=="nodetype" then
          nodetype_qstr=<<-EOM
             select n.id as nid, 'nt' as qno, 0 as relevance
             from nodes n 
             where #{qh[:cond]} and n.node_type!=2
          EOM
          sptmky.push(nodetype_qstr)
          cnt=cnt+1        
        end
      }
     #�m�[�h�^�C�v���摜�ł�����̂������Ώۂ���O��
      node_qstr_conditions.push("n.node_type!=2")
      # �m�[�h�^�C�v�́u�e�m�[�h���Y��������q���m�[�h�͑S���Y���v���[���͓K�p���Ȃ�     
      if node_qstr_conditions.size>0 then
        node_qstr=<<-EOM
          select n.id as nid, 'n' as qno, 0 as relevance
          from nodes n 
          where #{node_qstr_conditions.join(" and ")}
        EOM
      end
          
     #spatial_and_time_attributes�ɂ����錟���������\������
     if sptm_qstr_conditions.size>0 then
       sptm_qstr=<<-EOM
         select r.descendant as nid, 's' as qno, r.rel_depth as relevance
         from spatial_and_time_attributes s join node_lineages r on s.node_id = r.ancestor
         where #{sptm_qstr_conditions.join(" and ")}
       EOM
       cnt=cnt+1
       sptmky.push(sptm_qstr)
     end

     #�A�N�Z�X���̋L�q��������
     access_conditions = Node.conditions_to_read(user)
     if access_conditions!=nil then
       access_conditions="where "+access_conditions
     else
       access_conditions=""
     end
     
     #��̓�����킹�違nodes�ł̏����ipath�j�����킹��
     allqstr =<<-EOM
         select n.id as id, sum(score) as score
         from 
         (select nid,qno,max(relevance) as score
          from (#{sptmky.join(' union all ')}) ar
          group by nid,qno) q join nodes n on q.nid = n.id
         #{access_conditions}
         group by nid
         having count(distinct qno)=#{cnt}
         order by sum(score) desc;
     EOM
#     puts "++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
#     puts allqstr
#     puts "++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
#debugger
     return allqstr      
 end

 def get_condition4kw(description)
   description=~/(.*)\.(.*)=(.*)/
   qtype=$1
   qname=$2
   qvalue=$3
   options={
     :querytype=>"keyword",
     :cond=>"name = '#{$2}' and value = '#{$3}'",
     :description => description
   }
	p options
   return options
 end
 def get_condition4kwname(description)
   description=~/(.*)=(.*)/
   qtype=$1
   qname=$2
   $qname=$2
   options={
     :querytype=>"keyname",
     :cond=>"name = '#{$2}'",
     :description => description
   }
   #s "kname"
   return options
 end
 
 def get_condition4fw(description)
   description=~/(.*)=(.*)/
   qtype=$1
   qname=$2
   options={
     :querytype=>"freeword",
     :cond=>"name like '%#{$2}%' or value like '%#{$2}%'",
     :description => description
   }
   return options
 end
 
 def get_condition4time(description)
   description =~/(.*)=\[(.*),(.*)\]/
	p $2,$3
   options={
     :querytype=>"time",
     :cond=>"starttime <= '#{$3}' and endtime >= '#{$2}'",
     :description => description
	
	}
 end
 
 def get_condition4path(description)
  description=~/(.*)=(.*)/
   qtype=$1
   qname=$2
   options={
     :querytype => "path",
     :cond => "n.path = '#{qname}'",
   }   
   return options
 end
 
  def get_condition4nodetype(description)
   description=~/(.*)=(.*)/
   qtype=$1
   str=$2
   str.gsub!("data","directory,variable")
   qnames=str.split(/,/)
      
   nodetypes={"directory"=>0,
              "variable"=>1,
              "knowledge"=>3,
              "function"=>4,
              "draw_method"=>5}
              
   conds=Array.new
   qnames.each{ |qname|
     conds.push("n.node_type = #{nodetypes[qname]}")
   }             
   conds_str = conds.join(" or ")
   
   options={
     :querytype => "nodetype",
     :cond => "(#{conds_str})",
     :description => description     
   }   
   return options
 end
 
  def get_condition4space(description)
   description=~/(.*)\[(.*),(.*),(.*),(.*)\]/
  
   start_lon = ( $2 != "" ? $2 : "0" )
   start_lat = ( $3 != "" ? $3 : "-90" )
   end_lon = ( $4 != "" ? $4 : "360" )
   end_lat = ( $5 != "" ? $5 : "90" )

   @dateline=0  # dummy (horinout 2008/07/28): Kept for a while to avoid to be nil, but should be removed in fufure
   
   if start_lon.to_f > end_lon.to_f then
     qcond=<<-EOM
        ( longitude_lb >= #{start_lon} or longitude_rt <= #{end_lon} )
        and latitude_lb <= #{end_lat} and latitude_rt >= #{start_lat} 
        and not(node_id IS NULL)
     EOM
   else
     qcond=<<-EOM
        longitude_lb <= #{end_lon} and longitude_rt >= #{start_lon} 
        and latitude_lb <= #{end_lat} and latitude_rt >= #{start_lat} 
        and not(node_id IS NULL)
     EOM
   end
   options={
     :querytype=>"space",
     :cond=>qcond,
     :description => description
   }
   options[:spregion]=[start_lon,start_lat,end_lon,end_lat]

   return options
 end 

end
