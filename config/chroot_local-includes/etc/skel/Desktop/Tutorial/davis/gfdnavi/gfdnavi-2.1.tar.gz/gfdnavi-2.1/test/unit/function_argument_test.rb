require File.dirname(__FILE__) + '/../test_helper'

class FunctionArgumentTest < Test::Unit::TestCase
  fixtures :function_arguments

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
