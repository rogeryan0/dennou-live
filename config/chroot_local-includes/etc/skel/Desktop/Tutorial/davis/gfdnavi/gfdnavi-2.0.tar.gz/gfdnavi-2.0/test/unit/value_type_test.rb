require File.dirname(__FILE__) + '/../test_helper'

class ValueTypeTest < Test::Unit::TestCase
  fixtures :value_types

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
