require File.dirname(__FILE__) + '/../test_helper'

class FunctionTest < ActiveSupport::TestCase
  fixtures :functions, :function_arguments, :function_outputs, :nodes, :value_types

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
