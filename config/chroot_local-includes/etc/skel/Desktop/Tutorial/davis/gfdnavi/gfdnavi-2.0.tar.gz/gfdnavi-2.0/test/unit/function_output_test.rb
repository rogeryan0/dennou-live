require File.dirname(__FILE__) + '/../test_helper'

class FunctionOutputTest < Test::Unit::TestCase
  fixtures :function_outputs

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
