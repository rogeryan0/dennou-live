require File.dirname(__FILE__) + '/../test_helper'

class FigureCacheTest < Test::Unit::TestCase
  fixtures :diagram_caches

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
