require File.dirname(__FILE__) + '/../test_helper'

class DrawParameterTest < Test::Unit::TestCase
  fixtures :draw_parameters

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
