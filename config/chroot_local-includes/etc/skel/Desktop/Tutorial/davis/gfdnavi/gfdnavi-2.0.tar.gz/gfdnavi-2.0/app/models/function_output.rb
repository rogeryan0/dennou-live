class FunctionOutput < ActiveRecord::Base
  belongs_to :function
  acts_as_list :scope => :function
end
