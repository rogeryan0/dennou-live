require File.join(File.dirname(__FILE__), "application_controller")
