require "activerecord_gfdnavi"

class CrossArray
 #attr_accessor :keynames 
 attr_accessor :name,:keyvalue , :cnt

def initialize(id)
    #@keynames = Array.new
    #@resulttree=PathNode.new
    #@resulttree.path="/"
    #@resultids = Array.new
    #@nodes=Array.new
    #@qsetid=qsetid
	#puts "aa"
 @id=id
@name=Array.new
 #@name.push(name)
 #puts @name
	@keyvalue=Array.new
	@cnt=Array.new 
end
end
