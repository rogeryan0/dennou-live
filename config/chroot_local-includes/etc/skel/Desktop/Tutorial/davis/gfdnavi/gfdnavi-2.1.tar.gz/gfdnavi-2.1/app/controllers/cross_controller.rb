#!/usr/bin/ruby
#require "rdb_concat"
require 'rubygems'
require 'open-uri'
#require 'hpricot'
require "rexml/document"
require 'kconv'
require 'net/http'
require "socket"
require 'uri'
Net::HTTP.version_1_2 

class CrossController < ApplicationController
  layout "gfdnavi"
  
  def index
    # @queryconditions�͑S�����Aqcno�͑S�����̐�
    # params["query#{}"]�̓`�F�b�N�������Ă�������̂݊i�[
    # nofquery�̓`�F�b�N�������Ă�������̐�

    #�⍇���������̈����p���i�Ȃ���Ώ������j
    if session[:queryconditions] then
      @queryconditions=session[:queryconditions]
      @nodetypes=session[:nodetype]
   
    else
      @queryconditions=Array.new(0)
      @nodetypes=Hash.new(nil)
      session[:qcno]=0
    end
    if !session[:qcond_selection] then
      session[:qcond_selection]=Array.new
     session[:qcno]=0
    end
    #if session[:qcond_selection] then
      
    #end
    if !session[:qcno] then
       session[:qcno]=0
    end 
   #�T�[�o���X�g�̈����p���i�Ȃ���Ώ������j
    if session[:serverlist] then
      @serverlist=session[:serverlist]
    else
      @serverlist=Hash.new(nil)
      # puts "@serverlist.size",@serverlist.size
      result_at_server=ResultAtServer.new("localhost")
      result_at_server.id=0
      result_at_server.url=request.raw_host_with_port
      result_at_server.check=1      
      @serverlist[:localhost]=result_at_server
    end
    if !session[:selection] then
      session[:selection]=Array.new
    end
    if !session[:server_selection] then 
      session[:server_selection]=Array.new
      session[:nodetype]=Hash.new
    end
    if !session[:isInitial] then
       # $isInitial=1
       session[:isInitial]=1
    else
       # $isInitial=0
       session[:isInitial]=0
    end

   #���̃Z�b�V�������Ȃǂ͏��������Ă���
    #�ϐ��̏�����
    # @result_at_server=ResultAtServer.new(0) #�e�T�[�o�ł̌������� # @??? @modified 2011.1.18 chiemi
  #  $checken=0
    @previd=nil
    @qargs=nil
    @results=CrossResult.new()
    @pathtree=Array.new() #pathtree��name�i�[

    #�Z�b�V�������̏�����(���ꂼ��{���Ɏg���Ă��邩���m�F����)
    session[:previd]=nil
    #session[:qsetid]=1
    #�Z�b�V���������g���Ė⍇��������
    query_join(nil)
    cross_search()
    if @pathtrees==nil then
     @pathtree_html=nil
    else
     @pathtree_html = Hash.new
    end
    @pathtrees.keys.each{ |pt|    
         servername=pt
         @serverlist=session[:serverlist]         
         @serverlist.each_key{ |key|
	    if @serverlist[key].url==pt then ########## ���ϐ����폜�����֌W�ŕύX
		servername=key
	    end	     
	 }
        @pathtree_html[servername]= ResultInfo.get_pathtree_viewinfo(@pathtrees[pt],pt,relative_url_root)
     }

  end
    
  def check_box 

    @resultInfoList=Hash.new
    @resultInfoList[:all_servers]=ResultInfo.new("all_servers")
    
     #�T�[�o�̑I�� 
    @serverlist=session[:serverlist]
    cnt=0 
    i=0 
    
    @serverlist.each_key { |key|
     if params["server_selection_#{i}"]=="1" then
       #if @serverlist[key].check == 1 then
        session[:server_selection][i]=1
        
        url=@serverlist[key].url
        @serverlist[key].url=url
        @serverlist[key].check=1
      else
        @serverlist[key].check=0

        session[:server_selection][i]=0
      end
      i = i + 1
    }
    session[:serverlist]=@serverlist 
    @queryconditions=session[:queryconditions]###
    if @queryconditions != Array.new(0)  then ### ���܂Ō��������N�G��������ꍇ
      params[:nofquery]=@queryconditions.size###
      session[:qcno]=@queryconditions.size###
       query_join(nil)###
      cross_search()###
      show_result ### 
   else ###�@"all"�̏ꍇ
     
      session[:queryconditions]=nil ###
      @queryconditions=Array.new(0)###
      session[:qcond_selection]=nil####
    get_xml
    end###
    #get_xml
    
  end

  def reset
    session[:queryconditions]=nil
    session[:isInitial]=nil
    session[:qcond_selection]=nil
    session[:serverlist]=nil
    session[:selection]=nil
    session[:server_selection]=nil
    redirect_to :action=>"index"
  end

  def get_xml ##�S�t�@�Z�b�g���擾���鎞�̏���
    unless @serverlist == nil
      @serverlist.each_key{ |key|
        if @serverlist[key].check==1 then 
          if @serverlist[key].url==  request.raw_host_with_port  then
            url=@serverlist[key].url
            check=@serverlist[key].check
            params[:nofquery]=1
            params["show_facets"]=1
            params["show_kwvalues"]=1
            params["show_spfacets"]=1
            params["no_result"]=1
            params["show_pathtree"]=1
            
            xmlString=categorized_search()
            doc=xmlString.to_xml
            get_results(doc,key)
            if !@pathtrees then
              @pathtrees=Hash.new
            end
            if @pathtree==nil then
              @pathtrees[(url)]="no result"
            else
              @pathtrees[(url)]=@pathtree          
            end

            @serverlist[key].url=url
            @serverlist[key].check=check
          else 
             url=@serverlist[key].url
            check=@serverlist[key].check
            queryurl = "http://#{url}data/find(all).xml?show_kwfacets=1&show_kwvalues=1&show_spfacets=1&no_result=1"             
            begin
              ## �ڑ����Ԃ�ݒ肷��ꍇ
              uu=URI.parse("http://#{url}")
              # puts uu.host,uu.port,uu.path
              Net::HTTP.start(uu.host,uu.port){|http|
		http.read_timeout = 240
                doc= http.get("#{uu.path}data/find(all).xml?show_kwfacets=1&show_kwvalues=1&show_spfacets=1&no_result=1&show_pathtree=1").body
              }
              ##
              ## open-uri�ŊJ���ꍇ
              #doc = open(queryurl).read.toutf8 
              get_results(doc,key) 
              
              if !@pathtrees then
                @pathtrees=Hash.new
              end
              if @pathtree==nil then
                @pathtrees[url]="no result"
              else              
                @pathtrees[url]=@pathtree
              end
            rescue        
            end
            @serverlist[key].url=url
            @serverlist[key].check=check
          end
        end
      }   
    end
    session[:serverlist]=@serverlist
    show_result
  end
  
#==begin �L�[���[�h���N���b�N�����Ƃ��C���łɏ�����Ă���keyvalues��\�����邾���ɂ��� (written by chiemi)
  def show_keyvalues
    keyname=params[:keyname]
    render :update do |page|
      page.show("kw_#{keyname}")
      page.show("kw_#{keyname}_close")
    end
  end
  
  def hide_keyvalues
    keyname=params[:keyname]
    render :update do |page|
      page.hide("kw_#{keyname}")
      page.hide("kw_#{keyname}_close")
    end  
  end
  #==end  
  
  def query_join(desc)
    count=0
    i=1
    j=1
    #����܂ł̖⍇������
    if @queryconditions != nil then ###
#  if @queryconditions.size >= 1 ��L������������ɃR�����g�A�E�g���܂���
       @queryconditions.each {|q|
          if  session[:qcond_selection][i-1] == 1 then
            count=count+1
            params["query#{j}"]= q 
            j = j+1
          end
          #puts "***** query#{i}=#{q} ******"
          i = i+1
        }
     end
     # end
    #�V�����⍇������
    if desc then 
      params[:nofquery]=count+1
     if @queryconditions then ####
      @queryconditions.push(desc)
       else###
          @queryconditions=Array.new(0) ###
        @queryconditions.push(desc) ###
        session[:qcond_selection]=Array.new ###
     end ###
      session[:qcond_selection][i-1]=1
     session[:qcno]=session[:qcno]+1      
      # puts "***query*******",desc
      params["query#{count+1}"]=desc
    else
      params[:nofquery]=count
    end
    session[:queryconditions]=@queryconditions
  end

  def cross_search
    # @result_at_server=ResultAtServer.new(0)

    #==begin �ꎞ�I��@keyvalues�Ƃ����n�b�V��������Ă����i��X����, written by chiemi�j 
    @resultInfoList=Hash.new
    @resultInfoList[:all_servers]=ResultInfo.new("all_servers")
     #==end

    i=1  
    #�������Ȃ��Ă��� 
    query=""
    while i <= session[:qcno]
      if session[:qcond_selection][i-1]== 1 then
        query += params["query#{i}"].to_s
        if session[:qcno] > 1 && i != session[:qcno] then         
          query += "&"
        end
      end
      i = i+1
    end
    
    params["show_kwfacets"]=1
    params["show_kwvalues"]=1
    params["show_spfacets"]=1 
    params["no_result"]=1
    params["show_pathtree"]=1

    #    @serverlist=session[:serverlist]
    l=0
    @serverlist.each_key{ |key| ############# �ύX
      @resultInfoList[key]=ResultInfo.new(key)     
      url=@serverlist[key].url
      check=@serverlist[key].check
      id=@serverlist[key].id
      if   url ==  request.raw_host_with_port #localhost�̏ꍇ
        if check == 1 
          session[:server_selection][id]=1
          xmlString=categorized_search()
          # uu=URI.parse("http://davis.gfd-dennou.org/experimental/gfdnavi")
          # Net::HTTP.start(uu.host,uu.port){|http|
           # http.read_timeout = 240
            #puts http.get("#{uu.path}/data/find(kw.long_name=temperature).xml?show_kwfacets=1&show_kwvalues=1&show_spfacets=1&no_result=1&show_pathtree=1").body
          #}
          #puts uu.host,uu.port,uu.path
          doc=xmlString.to_xml
          get_results(doc,key)
          if !@pathtrees then
            @pathtrees=Hash.new
          end
          if @pathtree==nil then
            @pathtrees[(url)]="no result"
          else
            @pathtrees[(url)]=@pathtree
          end
        end    
      else
        if query=="" then
          query="all"
        end
        if check == 1
          # puts "cross search"
          crossurl = URI.encode("http://#{url}data/find(#{query}).xml?show_kwfacets=1&show_kwvalues=1&show_spfacets=1&no_result=1&show_pathtree=1")
          begin
            ## �ڑ����Ԃ�ݒ肷��ꍇ
            uu=URI.parse("http://#{url}")
            Net::HTTP.start(uu.host,uu.port){|http|
              http.read_timeout = 240
              doc= http.get(URI.encode("#{uu.path}data/find(#{query}).xml?show_kwfacets=1&show_kwvalues=1&show_spfacets=1&no_result=1&show_pathtree=1")).body
            }
            # open-uri�ŊJ���ꍇ�itimeout�͎w��ł��Ȃ��j
            #doc = open(crossurl).read.toutf8
            get_results(doc,key)   
            if !@pathtrees then
                @pathtrees=Hash.new
            end
            if @pathtree==nil then
              @pathtrees[url]="no result" 
            else
              @pathtrees[url]=@pathtree
            end
          rescue
          end
        end
      end 
    l=l+1
    }    
    session[:serverlist]=@serverlist  
    #show_result
  end
  
  
  ##���ʂ̕\��##
  def show_result
   # puts @queryconditions
    render :update do |page| 	  
      @serverlist=session[:serverlist] 
      
      #/*Gfdnavi Servers*/#
      #  if $isInitial !=0 then #������ʂł����
      page.replace_html "servers",""
      i=0
      @serverlist.each_key { |key|
        url=@serverlist[key].url
        page.insert_html :bottom,"servers","<div id=\"servers_#{i}\" style=\"font-size:18px;\"></div>"
        
        if session[:server_selection][i]==1 then
          # page.replace_html "servers_#{i}","#{check_box_tag("server_#{i}","1",true,{:name=>"server_selection_#{i}"})}<font color=\"red\">#{key}<a href=\"http://#{url}/\" TARGET=\"_blank\">\"http://#{@serverlist[key].url}\"</a></font><br>"
        #  page.insert_html :bottom,"servers_#{i}","#{observe_field("server_#{i}",:with=>"'server_#{i}='+(value)",:url=>{:action=>'check',:id=>i})}" 
          # page.insert_html :bottom,"servers_#{i}","#{observe_field("server_#{i}",:with=>"'server_#{i}='+(value)",:url=>{:action=>'g',:id=>i})}"
          page.insert_html :bottom, "servers","<div id= servers_#{i} style=\"font-size:18px;\"><input type=\"checkbox\" name=\"server_selection_#{i}\" value=\"1\" checked>#{key} <a href=\"http://#{@serverlist[key].url}/\" TARGET=\"_blank\">\"http://#{@serverlist[key].url}\"</a></div>"
          @serverlist[key].url=url
          params["server_selection_#{i}"]=1
        else
          #page.replace_html "servers_#{i}","<input type=\"checkbox\" name=\"server_selection_#{i}\" value=\"0\">#{key}<a href=\"http://#{url}/\" TARGET=\"_blank\">\"http://#{url}\"</a></div><br>"
         #page.replace_html "servers_#{i}","#{check_box_tag("server_#{i}","1",true,{:name=>"server_selection_#{i}"})}<font color=\"red\">#{key}<a href=\"http://#{url}/\" TARGET=\"_blank\">\"http://#{@serverlist[key].url}\"</a></font><br>"
         # page.insert_html :bottom,"servers_#{i}","#{observe_field("server_#{i}",:with=>"'server_#{i}='+(value)",:url=>{:action=>'check_box',:id=>i})}"
          page.insert_html :bottom, "servers","<div id= servers_#{i} style=\"font-size:18px;\"><input type=\"checkbox\" name=\"server_selection_#{i}\" value=\"1\">#{key}<a href=\"http://#{@serverlist[key].url}/\" TARGET=\"_blank\">\"http://#{@serverlist[key].url}\"</a></div>"
        end
        i= i+ 1
      }
      # end
      
      #/*QueryConditions*/
      i=0
      @queryconditions=session[:queryconditions]
      # if $checken == 0
      page.replace_html "qcond",""
       #if @queryconditions.size > 0 then #���L�ɕύX��������ɃR�����g�A�E�g���܂���(02/22)
      if @queryconditions  then
      page.insert_html :top,"qcond","<font>These terms define your current search.Please remove the check to remove a term. </font><br>"
      end
      spcond=0
      if @queryconditions != nil

        page.replace_html "spconditions","" 
        @queryconditions.each{ |q|
          if session[:qcond_selection][i]==1 then
            
            if @queryconditions.size > i+1
              page.insert_html :bottom,"qcond", "<span id=\"qcond_#{i}\" style=\"font-size:13px;\"></span>"
              page.replace_html "qcond_#{i}","#{check_box_tag("qconds_#{i}",1,true,{:name=>"qcond_selection_#{i}"})}#{q} & "
              
              page.insert_html :bottom,"qcond_#{i}","#{observe_field("qconds_#{i}",:with=>"'qcond_selection_#{i}='+(value)",:url=>{:action=>'queryconditions_selection',:id=>i})}"
            else
              page.insert_html :bottom,"qcond", "<span id=\"qcond_#{i}\" style=\"font-size:13px;\"></span>"
              page.replace_html "qcond_#{i}","#{check_box_tag("qconds_#{i}",1,true,{:name=>"qcond_selection_#{i}"})}#{q}"
              
              page.insert_html :bottom,"qcond_#{i}","#{observe_field("qconds_#{i}",:with=>"'qcond_selection_#{i}='+(value)",:url=>{:action=>'queryconditions_selection',:id=>i})}"
            end            
          else
            if @queryconditions.size > i+1
              page.insert_html :bottom,"qcond", "<span id=\"qcond_#{i}\" style=\"font-size:13px;\"></span>"
              page.replace_html "qcond_#{i}","#{check_box_tag("qconds_#{i}",1,false,{:name=>"qcond_selection_#{i}"})}#{q} & "
              page.insert_html :bottom,"qcond_#{i}","#{observe_field("qconds_#{i}",:with=>"'qcond_selection_#{i}='+(value)",:url=>{:action=>'queryconditions_selection',:id=>i})}"
              # page.insert_html :bottom,"qcond", "<li style=\"font-size:13px;\"><input type=\"checkbox\" name=\"qcond_selection_#{i}\" value=\"0\">#{q}</li>"      
            else
              page.insert_html :bottom,"qcond", "<span id=\"qcond_#{i}\" style=\"font-size:13px;\"></span>"
              page.replace_html "qcond_#{i}","#{check_box_tag("qconds_#{i}",1,false,{:name=>"qcond_selection_#{i}"})}#{q}"
              page.insert_html :bottom,"qcond_#{i}","#{observe_field("qconds_#{i}",:with=>"'qcond_selection_#{i}='+(value)",:url=>{:action=>'queryconditions_selection',:id=>i})}"
            end
          end
            
          #��ԑ����ɑ΂���⍇�������͒n�}�ɕ\�����邽�߂�@spcondition�ɕۑ�
          if q=~/sp.overlap\[(.*)\]/ then
            s=$1.split(/,/);
            str=<<-EOM
             (<span id=\"start_lon\">#{s[0]}</span>,
             <span id=\"start_lat\">#{s[1]}</span>)-
             (<span id=\"end_lon\">#{s[2]}</span>,
             <span id=\"end_lat\">#{s[3]}</span>)
            EOM
            page.insert_html :bottom,"spconditions","<div id=\"spconditions_#{spcond}\"></div>"
            page.replace_html "spconditions_#{spcond}", str
            spcond=spcond+1
          end
          i=i+1
        }        
        page.insert_html :bottom,"qcond"," <center><submit_tag(\"selection\")></center>"
        session[:queryconditions]=@queryconditions
      end
      #/*Keyword*/    
     page.replace_html "keyword","<ul id='keyword_list'></ul>"
     #===begin keyvalues�����łɊi�[���Ă����i��\���ɂ��Ă����āA�N���b�N���ꂽ�猩���悤�ɂ���j written by chiemi
      @resultInfoList[:all_servers].get_keynames_sorted.each{ |kname|
             count=@resultInfoList[:all_servers].get_keyvalue_count(kname,:all_values)
             page.insert_html :bottom, "keyword_list", "<li>#{link_to_remote(kname,{:url=>{:action=>'show_keyvalues',:keyname=>kname},:before=>'showLoadingIconAll()', :complete=>'hideLoadingIconAll()'})}(#{count})</li>"
	     close="[CLOSE]"
             page.insert_html :bottom, "keyword_list", "<ul><div id=\"kw_#{kname}\" style=\"display:none;\"></div><div id=\"kw_#{kname}_close\" style=\"display:none\">#{link_to_remote(close,{:url=>{:action=>'hide_keyvalues',:keyname=>kname}})}</div>"
        @resultInfoList[:all_servers].get_keyvalues_sorted(kname).each{ |kvalue,count|
           if kvalue!=:all_values then
             page.insert_html :bottom, "kw_#{kname}", "<li>#{link_to_remote(kvalue,{:url=>{:action=>'cross_kw',:keyname=>kname, :keyvalue=>kvalue},:before=>'showLoadingIconAll()', :complete=>'hideLoadingIconAll()'})}(#{count})</li>"
           end
        }
      }      
#===end
    #/*partial_covered*/
    @serverlist=session[:serverlist]
    ppa=Hash.new()
    sum_partial = Hash.new()
    page.replace_html "partial_covered",""
    i=0    
    @resultInfoList[:all_servers].partial.each_key{ |reg|
          cnt=@resultInfoList[:all_servers].get_count_partial(reg)
	  region=reg.split(/_/)	  
          page.insert_html :bottom,"partial_covered","<div id=\"patial_group_#{i}\"></div>"
          page.replace_html "patial_group_#{i}",  "(<span id=\"lontitude_lb\">#{region[0]}</span>,<span id=\"latitude_lb\">#{region[1]}</span>)-(<span id=\"lontitude_rt\">#{region[2]}</span>,<span id=\"latitude_rt\">#{region[3]}</span>) [#{cnt}]" 	
	  i=i+1
    }
    
    #/*point*/
    ppp=Hash.new()
    sum_point = Hash.new()
    page.replace_html "box","<input type=\"checkbox\" name=\"points\" onclick=\"show_points(this);\" checked> point"
    page.replace_html "points",""
    i=0    
    @resultInfoList[:all_servers].point.each_key{ |pos|
          cnt=@resultInfoList[:all_servers].get_count_point(pos)
	  position=pos.split(/_/) 
          page.insert_html :bottom,"points","<div id=\"point_group_#{i}\"></div>"
          page.replace_html "point_group_#{i}",  "(<span id=\"lontitude\">#{position[0]}</span>,<span id=\"latitude\">#{position[1]}</span>)[<span id=\"count\">#{cnt}</span>]" 
	  i=i+1
    }
    
    #/*Result*/
    
    $analviz_tag = image_tag('tree/anal_viz.png', :alt=>'Anal/Vis',
                             :title=>'Analyze/visualize variables in this folder',
                             :border=>0,:align=>'absmiddle')
    $details = image_tag('tree/details.png',:alt=>'details', :title=>'Show details',:border=>0,:align=>'absmiddle')
            
    page.replace_html "results",""
    
    if !@pathtrees then
       return
    end
    prevDepth=-1
    @pathtrees.keys.each{ |pt|
       # puts pt
       serverurl=pt
       servername=pt
        
       i=0         
       @serverlist=session[:serverlist]         
       @serverlist.each_key{ |key|
		  if @serverlist[key].url==pt then ########## ���ϐ����폜�����֌W�ŕύX
                     servername=key
                  end
                  i=i+1
	   }
       page.insert_html :bottom, "results", "<h2>********** #{servername} **********</h2>"
       #���ʂ��[���������玟�̃T�[�o�ɐi��ł��܂�
       if @pathtrees[pt]=="no result" then
         page.insert_html :bottom, "results", @pathtrees[pt]
         next;
       end
        
        viewInfoList =  ResultInfo.get_pathtree_viewinfo(@pathtrees[pt],serverurl,relative_url_root)
     if viewInfoList!=nil then
	 if viewInfoList.size>0 then
	    viewInfoList.each{ |viewInfo|
		divid="st_#{viewInfo[:nodepath]}"
	        page.insert_html :bottom, "results", "<div id=#{divid}></div>"
	    if viewInfo[:treeicon] == "plus" then
		iconwithlink="#{link_to_remote(image_tag(viewInfo[:imgsrc],:border=>0),{:url=>{:controller=>"cross", :action=>"get_subpathtree",:display_path=>viewInfo[:display_path], :input_path=>viewInfo[:input_path], :input_server=>viewInfo[:input_server], :restNodes=>viewInfo[:restNodes], :depth=>viewInfo[:depth]}},{:border=>0})}"
		page.insert_html :bottom, divid, "#{viewInfo[:indent]}#{iconwithlink}#{viewInfo[:display_path]}(#{viewInfo[:count]})"
	    else
		  iconwithlink="#{link_to_remote(image_tag(viewInfo[:imgsrc],:border=>0),{:url=>{:controller=>"cross", :action=>"close_subpathtree",:display_path=>viewInfo[:display_path], :input_path=>viewInfo[:input_path], :input_server=>viewInfo[:input_server], :restNodes=>viewInfo[:restNodes], :depth=>viewInfo[:depth]}},{:border=>0})}"		    
		  page.insert_html :bottom, divid, "#{viewInfo[:indent]}#{iconwithlink}#{viewInfo[:display_path]}(#{viewInfo[:count]})"
		  if viewInfo.has_key?(:objInfoList) then
			 viewInfo[:objInfoList].each{ |objInfo|
			   page.insert_html :bottom, divid, "<br>#{objInfo[:indent]}<img src=\"#{objInfo[:imgsrc]}\">#{objInfo[:objname]}"
			   page.insert_html :bottom, divid, "#{link_to(image_tag('tree/details.png', :alt=>'details', :title=>'Show details', :border=>0),objInfo[:url],:target=>'_brank')}"
			   if objInfo.has_key?(:analysis) then
				page.insert_html :bottom, divid, "#{link_to(image_tag('tree/anal_viz.png',:alt=>'Anal/Vis', :title=>'Analysis/Visualize',:border=>0), objInfo[:analysis], :target=>'_brank')}"
			   end
			   if objInfo.has_key?(:knowledge) then 
				page.insert_html :bottom, divid, "#{link_to(image_tag('tree/show.png',:alt=>'Show knowledge', :border=>0), objInfo[:knowledge], :target=>'_brank')}"
			   end
=begin			   
			   if objInfo.has_key?(:analysis) then 
				page.insert_html :bottom, divid, "#{link_to(image_tag('tree/show.png',:alt=>'Show knowledge', :border=>0), objInfo[:image], :target=>'_brank')}"
			   end			   
=end			   
			 }
		  end
	    end	
        }
     end
     end
	 #page.insert_html :bottom, "results", insert_string
       }# @pathtrees.keys.each{ |pt|
      #/*map*/
      page << "initialize();"
  end 
end
  
def close_subpathtree
    display_path=params["display_path"]
    input_path=params["input_path"]
    input_server=params["input_server"]
    depth=params["depth"].to_i
    count=params["count"]
    restNodes=Array.new
    params["restNodes"].each{ |r|
      restNodes.push(r.to_i)
    }

    tagid="st_#{input_server.gsub("/","_")}_#{input_path.gsub("/","_")}_"
    render :update do |page|
      #�N���b�N�����s������������
      page.replace_html tagid,""
      #�C���f���g�\��
      indents_tmp=""
      if depth>0 then
        for d in 0..depth-1
          if restNodes[d]>0 then
            indents_tmp="#{indents_tmp}<img src=#{relative_url_root}/images/tree/tate.png>"
          else
            indents_tmp="#{indents_tmp}<img src=#{relative_url_root}/images/tree/space.gif>"
          end
        end
     end #depth>0
     if restNodes[depth]==1 then
       indents="#{indents_tmp}<img src=#{relative_url_root}/images/tree/last.png>"
     else
       indents="#{indents_tmp}<img src=#{relative_url_root}/images/tree/t.png>"
     end
     nodepath="#{input_server}_#{input_path.gsub("/","_")}"
     nodename=display_path     
     imgsrc="#{relative_url_root}/images/tree/plus.gif"
     iconwithlink="#{link_to_remote(image_tag(imgsrc,:border=>0),{:url=>{:controller=>"cross",:action=>"get_subpathtree",:display_path=>nodename, :input_path=>input_path, :input_server=>input_server, :restNodes=>restNodes, :depth=>depth}},{:border=>0})}"
     page.insert_html :bottom,tagid,"<span id=st_#{nodepath}>#{indents}#{iconwithlink}#{nodename}(#{count})</span>"
     
    end

end
  
def get_subpathtree
	
    @resultInfoList=Hash.new
    @resultInfoList[:all_servers]=ResultInfo.new("all_servers")
    
    display_path=params["display_path"]
    input_path=params["input_path"]
    input_server=params["input_server"]
    depth=params["depth"].to_i
    restNodes=Array.new
    params["restNodes"].each{ |r|
      restNodes.push(r.to_i)
    }
    
    #�\���p�p�����^�̐ݒ�
    options=Hash.new
    options["show_kwfacets"]=0
    options["show_kwvalues"]=0
    options["show_spfacets"]=0 
    options["no_result"]=1
    options["show_pathtree"]=1
    
  #���������͂��łɎ��s���ꂽ���̂��ێ�����
  descriptions=Array.new
  i=0    
  query=""
  @queryconditions=session[:queryconditions]
  if session[:qcno] > 0 then
    @queryconditions.each { |q|
      if session[:qcond_selection][i]==1 then
        query += q
        descriptions.push(q)
        if session[:qcno] > 1 && i != session[:qcno] then         
          query += "&"
        end
      end
      i = i+1
    }
    
    #description��path�̏�����ǉ�����
    descriptions.push("path=#{input_path}")
  else    
    query="all"
    descriptions.push("path=#{input_path}")  
  end
  
  #�w�肳�ꂽ�T�[�o�ɖ⍇�����ɍs��    
     
    if input_server == request.raw_host_with_port then
    #(���[�J���j
      user = (login=session[:user]) && User.find_by_login(login) 
      eq=NodeQuery.new
      qstr = eq.make_query(descriptions,user)
      storage=temp_storage
	    if qstr!="all" then
	      tmptable_name="tmptable_#{Time.now.to_i}"
	      qstr="create table #{tmptable_name} as #{qstr}"
	      Node.connection.execute(qstr)
	      xmlString=eq.generate_results_fromtmptable(0,tmptable_name,options,user)	    
          Node.connection.execute("drop table #{tmptable_name}") #delete temporary table
	    else
	      xmlString=eq.generate_results_fromtmptable(1,tmptable_name,options,user)	    
	    end
      
      isInitial=0
      session[:isInitial]=isInitial#====begin�@isInitial��session�ɂ��܂����B
      doc=xmlString.to_xml
      
     #   puts doc
      get_results(doc,"localhost")
    else
    #�i�����[�g�j
        url = "http://#{input_server}data#{input_path}/find(#{query}).xml?show_kwfacets=0&show_spfacets=0&no_result=1&show_pathtree=1" 
        begin
          doc = open(url).read.toutf8              
          get_results(doc,input_server) #===begin �����ύX�̕K�v����(doc,�T�[�o��)�ɂ��Ȃ���΂Ȃ�Ȃ�
        rescue
        end
    end
    #���ʂ�\������
    tagid="st_#{input_server.gsub("/","_")}_#{input_path.gsub("/","_")}_"
    ptStack=Array.new
    ptStackDepth=Array.new
    ptStack.push(@pathtree)
    ptStackDepth.push(depth) 
    rootnode_flg=1
    render :update do |page|
      #�N���b�N�����s������������
      page.replace_html tagid,""
      fstflg=1
      while ptStack.size>0
        if fstflg==1 then
          fstflg=0
        else
          page.insert_html :bottom,tagid,"<br/>"
        end
        dir=ptStack.pop
        depth=ptStackDepth.pop
        if dir then
          if dir.elements["name"] then
            indents_tmp=""
            if depth>0 then
              for d in 0..depth-1
                if restNodes[d]>0 then
                  indents_tmp="#{indents_tmp}<img src=#{relative_url_root}/images/tree/tate.png>"
                else
                  indents_tmp="#{indents_tmp}<img src=#{relative_url_root}/images/tree/space.gif>"
                end
              end
            end #depth>0
            if restNodes[depth]==1 then
              indents="#{indents_tmp}<img src=#{relative_url_root}/images/tree/last.png>"
            else
              indents="#{indents_tmp}<img src=#{relative_url_root}/images/tree/t.png>"
            end
            prevDepth=depth
            nodepath="#{input_server}_#{dir.elements["path"].text.gsub("/","_")}"
            #�W�J����T�u�c���[�̃��[�g�m�[�h
            if rootnode_flg==1 then
                path_array=input_path.split(/\//)
                path_array.pop
                if path_array.size==0 then
                  input_path_parent=""
                else
                  input_path_parent=path_array.join("/")
                end
                
	            dir.elements["name"].text=~/#{input_path_parent}\/(.*)/
	            nodename=$1
	            ipath=input_path
	            rootnode_flg=0
            else
                nodename=dir.elements["name"].text
                ipath=dir.elements["path"].text
                ipath.strip!
                strlength=ipath.size
                if ipath[strlength-1]=="/"[0] then
                  ipath=ipath[0..strlength-2]
                end                
            end
=begin
            if input_path==dir.elements["name"].text then
              nodename=display_path
            else
              nodename=dir.elements["name"].text
            end
=end           
			
            
            if dir.elements["treeicon"] then
             if dir.elements["treeicon"].text=="plus" then
              imgsrc="#{relative_url_root}/images/tree/plus.gif"
              iconwithlink="#{link_to_remote(image_tag(imgsrc,:border=>0),{:url=>{:controller=>"cross",:action=>"get_subpathtree",:display_path=>nodename, :input_path=>ipath, :input_server=>input_server, :restNodes=>restNodes, :depth=>depth}},{:border=>0})}"
             elsif dir.elements["treeicon"].text=="minus" then
              imgsrc="#{relative_url_root}/images/tree/minus.gif"
              count=dir.elements["count"].text
              iconwithlink="#{link_to_remote(image_tag(imgsrc,:border=>0),{:url=>{:controller=>"cross",:action=>"close_subpathtree",:display_path=>nodename, :input_path=>ipath, :input_server=>input_server, :restNodes=>restNodes, :depth=>depth, :count=>count}},{:border=>0})}"
             end
            else
              imgsrc="#{relative_url_root}/images/helpmark16.png"
              iconwithlink="<img src=#{imgsrc} border=0>"            
            end
            #���[�t�m�[�h�̏ꍇ�C�܂��̓I�u�W�F�N�g�������Ă��Ȃ���΁|�A�C�R����\��
            if dir.elements["leaf"]==1 && dir.elements["hasobj"]==0 then
              page.insert_html :bottom,tagid,"<span id=st_#{nodepath}>#{indents}<img src=#{relative_url_root}/images/tree/minus.gif>#{nodename}(#{dir.elements["count"].text})</span>"
            else
              page.insert_html :bottom,tagid,"<span id=st_#{nodepath}>#{indents}#{iconwithlink}#{nodename}(#{dir.elements["count"].text})</span>"
            end
            #�q�m�[�h���v�b�V������i�f�B���N�g���̏ꍇ�j
            cdirs=dir.elements["directories"]
            if cdirs && cdirs.class.to_s=="REXML::Element" then
              cdirs.each{ |d|
                if d.class.to_s=="REXML::Element" then
                  ptStack.push(d)
                  ptStackDepth.push(depth+1)
                  if restNodes.size<=depth+1 then
                    restNodes[depth+1]=1
                  else
                    restNodes[depth+1]=restNodes[depth+1]+1
                  end
                end
              }
            end
            #�q�m�[�h���v�b�V������i���[�t�m�[�h�̏ꍇ�j
            cobjs=dir.elements["objects"]
            if cobjs && cobjs.class.to_s=="REXML::Element" then
              i=1
              objsize=0
              cobjs.each{ |o| 
                if o.class.to_s=="REXML::Element" then
                  objsize=objsize+1
                end
              }              
              
              cobjs.each{ |o|                
                if o.class.to_s=="REXML::Element" then
                  path=o.elements["path"].text
                  nodeid=o.elements["id"].text
                  node_type=o.elements["node-type"].text.to_i
                  objname=o.elements["path"].text.split("/").pop
                  indents="#{indents_tmp}<img src=#{relative_url_root}/images/tree/tate.png>"
                  if i<objsize then
                    indents="#{indents}<img src=#{relative_url_root}/images/tree/t.png>"
                  else
                    indents="#{indents}<img src=#{relative_url_root}/images/tree/last.png>"                  
                  end
                  
                    if relative_url_root!="" then
                      urlprefix="http://#{input_server}#{relative_url_root}"
                    else
                      urlprefix="http://#{input_server}"
                    end
                  url=urlprefix+"/data"+path+".html"
                  str=<<-EOM
                   <br>#{indents}<img src=#{relative_url_root}/images/tree/page.gif> #{objname}                    
                   #{link_to(image_tag('tree/details.png',:alt=>'details',:title=>'Show details',:border=>0),url,:target=>'_brank')}                   
                  EOM
                  
                  if node_type==Node::VARIABLE then
                     avurl=urlprefix+"/finder/add_to_list?path="+path
                     str="#{str} #{link_to(image_tag('tree/anal_viz.png',:alt=>'Anal/Vis',:title=>'Analysis/Visualize',:border=>0),avurl,:target=>'_brank')}"
                  elsif node_type==Node::KNOWLEDGE then
                     knurl=urlprefix+"/knowledge/show?path=#{path}"
                     str="#{str} #{link_to(image_tag('tree/show.png',:alt=>'Show',:title=>'Show knowledge',:border=>0),knurl,:target=>'_brank')}"                  
                  elsif node_type==Node::IMAGE then
                     str="#{str} #{link_to(image_tag('tree/show.png',:alt=>'Show',:title=>'Show knowledge',:border=>0),url,:target=>'_brank')}"                  
                  end
                  page.insert_html :bottom,tagid,"#{str}"
                  i=i+1
                end #if o.class.to_s=="REXML::Element" then
              }#cobjs.each{ |o|
            end #if cobjs && cobjs.class.to_s=="REXML::Element" then           
          end #if dir.elements["name"] then
        end #if dir
    end #while ptStack.size>0
  end # render :update do |page|
end  
  
##localhost�ɂ�錟�����ʂ̎擾##
  def categorized_search
    descriptions=Array.new
    params["show_kwfacets"]=1
    params["show_kwvalues"]=1
    params["show_spfacets"]=1
    params["no_result"]=1
    params["show_pathtree"]=1
   # puts "params[:nofquery]=#{params[:nofquery]}"
   # puts "session[:qcno]=#{session[:qcno]}"
    #puts "params[query],#{params[:nofquery]}"
    #puts "@queryconditions,#{@queryconditions}"
    if params[:nofquery] == 1  && @queryconditions == nil then 
      # puts "all"
       @queryconditions="all" 
      descriptions.push("all")
    else
      if params[:nofquery]!=nil then 
        for i in 1..params[:nofquery].to_i do
          if params["query#{i}"] != nil then
            if /kw=/ =~ params["query#{i}"] 
              end                
            unless params["query#{i}"] == "all"              
              descriptions.push(params["query#{i}"])
            end
          end
        end
      end
    end
    # puts "descriptions",descriptions
    options=Hash.new
    if params["show_kwfacets"] then
      options["show_kwfacets"]=params["show_kwfacets"]
    else
      options["show_kwfacets"]=0   
    end
    if params["show_spfacets"] then
      options["show_spfacets"]=params["show_spfacets"]
    else
      options["show_spfacets"]=0   
    end
    if params["show_kwvalues"] then
      options["show_kwvalues"]=params["show_kwvalues"]
    else
      options["show_kwvalues"]=1
    end
    if params["no_result"] then
      options["no_result"]=params["no_result"]
    else
      options["no_result"]=0   
    end 
    if params["show_pathtree"] then
      options["show_pathtree"]=params["show_pathtree"]
    else
      options["show_pathtree"]=0   
    end

   
    user = (login=session[:user]) && User.find_by_login(login)
    eq=NodeQuery.new

 	storage=temp_storage

     if @queryconditions.size>0 then

       isInitial=0
      if @queryconditions[0] == "all" then
        @queryconditions = Array.new(0)
      end
      qstr = eq.make_query(descriptions,user)
      tmptable_name="tmptable_#{Time.now.to_i}"

      qstr="create table #{tmptable_name} #{storage} as #{qstr}"

      Node.connection.execute(qstr)
      
    else
     # $isInitial=1
       isInitial=1
    end
    #session[:isInitial]=$isInitial #===begin isInitial��session�ɂ��܂���
    session[:isInitial]=isInitial 
   # res=eq.generate_results_fromtmptable($isInitial,tmptable_name,options) 
    res=eq.generate_results_fromtmptable(session[:isInitial],tmptable_name,options,user)
    # if $isInitial==0 then 
    if session[:isInitial]==0 then
      Node.connection.execute("drop table #{tmptable_name}") #�ꎞ�e�[�u��������
    end
    return res
  end

  ###�t�@�Z�b�g�ƌ��ʂ̎擾### 
  def get_results(xmlString,servername)#===begin �T�[�o����n���悤�ɂ��܂���
    #@qsetid=session[:qsetid] 
    @results=CrossResult.new()
    if !@resultInfoList[servername] then
      @resultInfoList[servername]=ResultInfo.new(servername)
    end

    #DOM����
    doc = REXML::Document.new(xmlString)

    #point
    point = Hash.new
    xpath = "//point" 
    l=0
    doc.elements.each(xpath) do |e|      
      str1=e.elements["latitude-lb"] 
      str2=e.elements["longitude-lb"] 
      str3=e.elements["count"]
      array=str1.text
      array2=str2.text
      array3=str3.text
      
      point.store("#{array2}_#{array}","#{array3}")
    end
    @resultInfoList[servername].add_point(point)
    @resultInfoList[:all_servers].add_point(point)
    
    #partial_covered
    partial = Hash.new
    xpath = "//partial-covered/partial-covered" 
    doc.elements.each(xpath) do |e|
      str1=e.elements["latitude-lb"] 
      str2=e.elements["longitude-lb"] 	
      array=str1.text
      array2=str2.text
      str1=e.elements["latitude-rt"]
      str2=e.elements["longitude-rt"]
      array3=str1.text
      array4=str2.text
      str3=e.elements["count"]
      array5=str3.text
      partial.store("#{array2}_#{array}_#{array4}_#{array3}","#{array5}")
    end
    
    @resultInfoList[servername].add_partial(partial) 
    @resultInfoList[:all_servers].add_partial(partial)
       
   #all_covered
    all_covered = Hash.new
    xpath = "//all-covered/all-covered" 
    doc.elements.each(xpath) do |e|
      str1=e.elements["latitude-lb"] 
      str2=e.elements["longitude-lb"] 	
      array=str1.text
      array2=str2.text
      str1=e.elements["latitude-rt"]
      str2=e.elements["longitude-rt"]
      array3=str1.text
      array4=str2.text
      str3=e.elements["count"]
      array5=str3.text
      all_covered.store("#{array2}_#{array}_#{array4}_#{array3}","#{array5}")
    end
    
    @resultInfoList[servername].add_all_covered(all_covered) 
    @resultInfoList[:all_servers].add_all_covered(all_covered)
    #keyword
    keyword = Hash.new
    l=0
    xpath = "//keyword" 
    doc.elements.each(xpath) do |e|
      str1=e.elements["keyname"] 
      str2=e.elements["count"] 
      keyname=str1.text
      count=str2.text
      @resultInfoList[servername].set_keyname_count(keyname,count)
      @resultInfoList[:all_servers].add_keyname_count(keyname,count)
      if keyname=="long_name" then
      end
                 
#===begin keyvalues��XML�Ɋ܂܂�Ă������̑Ώ� (written by chiemi at 20101101)-
      values=e.elements["keyvalues"]      
      if values && values.class.to_s=="REXML::Element" then
        values.each{ |v|
          if v.class.to_s=="REXML::Element" then
            keyvalue=v.elements["keyvalue"].text
            count=v.elements["count"].text.to_i
            @resultInfoList[servername].add_keyvalue_count(keyname,keyvalue,count)
            @resultInfoList[:all_servers].add_keyvalue_count(keyname,keyvalue,count)
            if keyname=="long_name" && keyvalue="temperature" then
            end
          end
        }
      end
#===end
    end
    #pathtree
    if doc.root.elements["//pathtree"] then
      @pathtree=doc.root.elements["//pathtree"]
    else
      @pathtree=nil
    end
  end
 
 ##�p�X�c���[�擾##   
   def get_pathtree(xmlString)   
     @pathtree=Array.new()
     doc = REXML::Document.new(xmlString)
     
     xpath1 = "//pathtree" 
   
     doc.elements.each(xpath1) do |e1|     
       str1=e1.elements["name"]
       array=str1.text
       @pathtree.push(array)
       xpath2= "//directories"
       e1.elements.each(xpath2) do |e2|
         str2=e2.elements["directory"]
         i=0        
         e2.elements.each("directory") do |e3|       
           e3.elements.each("directory") do |e4|            
           end           
           str3=e3.elements["name"]
           i = i + 1
          end   
       end
     end
     # return @path     
   end
   
   def display
     render :action=>"_result.rhtml"
   end
   
   def cross_kw
    # $isInitial=0
     session[:isInitial]=0
     desc="kw.#{params[:keyname]}=#{params[:keyvalue]}"
     @serverlist=session[:serverlist]
     @queryconditions=session[:queryconditions]
     query_join(desc)
     cross_search
     show_result
  end
   
   def cross_freeword
    # $isInitial=0
     session[:isInitial]=0
     @serverlist=session[:serverlist]
     @queryconditions=session[:queryconditions]
     @serverlist=session[:serverlist]     
     desc="fw=#{params[:freeword]}"
     query_join(desc)
     cross_search
     show_result
     session[:serverlist]=@serverlist     
   end
  
   def cross_space
   #  $isInitial=0
     session[:isInitial]=0
    desc="sp.overlap[#{params[:start_lon]},#{params[:start_lat]},#{params[:end_lon]},#{params[:end_lat]}]"
     @serverlist=session[:serverlist]
     @queryconditions=session[:queryconditions]
    query_join(desc)
    cross_search
    show_result
  end
  
  def cross_time
    # $isInitial=0
     session[:isInitial]=0	  
    desc="tm=[#{params[:starttime]},#{params[:endtime]}]"
     @serverlist=session[:serverlist]
     @queryconditions=session[:queryconditions]
     @serverlist=session[:serverlist]
    query_join(desc)
    cross_search
    show_result
  end
  
 
   def queryconditions_selection
    # $isInitial=0
     session[:isInitial]=0	   
    num=0
    k=0
     @serverlist=session[:serverlist]
     @queryconditions=session[:queryconditions]
    
    l=params[:id].to_i
     for i in 0..session[:qcno].to_i-1
      if i == l then    
         if session[:qcond_selection][i] == 1 then
           session[:qcond_selection][i]=0
         else
           session[:qcond_selection][i]=1
           params["query#{num+1}"]=@queryconditions[i]
         num=num+1
         end
      else
           if session[:qcond_selection][i] == 0 then          
             session[:qcond_selection][i]=0           
           else          
             session[:qcond_selection][i]=1            
             params["query#{num+1}"]=@queryconditions[i]
       num=num+1         
           end
      end
      k=k+1
    end   
     
  
    # for i in 0..session[:qcno].to_i-1
      # s "#{@queryconditions[i]}=#{session[:qcond_selection][i]}"
    # end
      
     i=0
     @serverlist.each_key{|key|
       c=@serverlist[key].check
       if c==1 then
         session[:server_selection][i]=1
       else
         session[:server_selection][i]=0
       end
       i=i+1
     }
    
    if num==0 then

      	@queryconditions=Array.new
      	session[:queryconditions]=@queryconditions
     #  params[:nofquery]=1
     # session[:qcond_selection]=Array.new
      	session[:qcno]=0
	@resultInfoList=Hash.new
    	@resultInfoList[:all_servers]=ResultInfo.new("all_servers")
     
      get_xml
    else 
      params[:nofquery]=num	
      cross_search 
      show_result
    end
  end
 
  def get_servers
    @serverlist=Hash.new(0)
    @serverlist = session[:serverlist]  
#     url = GFDNAVI_CROSS_SEARCH_CENTER_SERVER

    url="https://davis.gfd-dennou.org/gfdnavi_portal/display/server_list"
 
    serverlist = open(url,:proxy => nil).read.toutf8
    serverlist = REXML::Document.new(serverlist)
    i=0
    xpath = "servers/server"
    serverlist.elements.each(xpath) do |e|    
      str1=e.elements["name"] 
      str2=e.elements["id"]
      str3=e.elements["url"]
      array=str1.text
      array2=str2.text 
      array3=str3.text 
      
      if !@serverlist.has_key?(array) then
	 @serverlist[array]=ResultAtServer.new(array)
#	 @serverlist[array].isInitial=$isInitial
        @serverlist[array].isInitial=session[:isInitial]
	 @serverlist[array].id=i
	 @serverlist[array].url=array3
          i=i+1
      end
    end
    
    session[:previd]=nil
    @results=CrossResult.new()
    session[:serverlist]=@serverlist
    
    i=0     
    render :update do |page|
      page.replace_html "servers",""      
      @serverlist.each_key{|key|

        url=@serverlist[key].url        
        if url==request.raw_host_with_port 

          page.insert_html :bottom, "servers","<div id= servers_#{i} style=\"font-size:18px;\"><input type=\"checkbox\" name=\"server_selection_#{i}\" value=\"1\" checked>#{key} <a href=\"http://#{@serverlist[key].url}/\" TARGET=\"_blank\">\"http://#{@serverlist[key].url}\"</a></div>"
        else
          page.insert_html :bottom, "servers","<div id= servers_#{i} style=\"font-size:18px;\"><input type=\"checkbox\" name=\"server_selection_#{i}\" value=\"1\">#{key} <a href=\"http://#{url}\" TARGET=\"_blank\">\"http://#{url}\"</a></div>" 
        end        
        i=i+1        
        params[:id]=i 
      }
      
    end
  end
  
  def  check
    l=params[:id].to_i
    @serverlist=session[:serverlist] 
    
    if params["server_#{l}"]=="1" then
      session[:selection][l]=1 
      @serverlist.each_key {|key|
        if l==@serverlist[key].id
          @serverlist[key].check=1     
        end
      }
    else
      
      session[:selection][l]=0
      @serverlist.each_key {|key|
        if l==@serverlist[key].id
          @serverlist[key].check=0    
        end
      }
     # $check[l]=0
      
    end
  
   # $checken=1
    show_result
   # $checken=0
  end
     
     
def nodetype_selection
    num=0
    flag=0
    # @result_at_server=ResultAtServer.new(0)
    @serverlist=session[:serverlist]
    @queryconditions=session[:queryconditions]
 
    types=Array.new
   @nodetypes=session[:nodetype]
   
    ntypes=["data","knowledge","function","draw_method"]
    ntypes.each{ |nt|
   
      value=params["nodetype_#{nt}"]
        if params["nodetype_#{nt}"]==nil  then #�`�F�b�N�{�b�N�X���ύX����Ă��Ȃ�
          if @nodetypes[nt]!=0 then
            types.push(nt)
            num=num+1
            @nodetypes[nt]=1
          else
            @nodetypes[nt]=0
          end
        else #�`�F�b�N�{�b�N�X��ύX������
           if @nodetypes[nt] ==0 then #�ύX����O�Ƀ`�F�b�N�������Ă��Ȃ������ꍇ
            types.push(nt)
            num=num+1
            @nodetypes[nt]=1
          else #�ύX����O�Ƀ`�F�b�N�������Ă����ꍇ
            
            @nodetypes[nt]=0
          end
        end
     
    }
 
    session[:nodetype]=@nodetypes
   
    if num==0 then
      
     # $isInitial=1
      session[:isInitial]=1
      @resultInfoList=Hash.new
      @resultInfoList[:all_servers]=ResultInfo.new("all_servers")
      @queryconditions=Array.new(0)
      session[:queryconditions]=@queryconditions
      
      show_result

    else
     # $isInitial=0
      session[:isInitial]=0
      types_str=types.join(",")       
      @queryconditions=session[:queryconditions] 
    
     
      if @queryconditions != Array.new then #�������������������
      
        qnum=0
        qcond=0
        @queryconditions.each { |q|
          if q =~/(.*)=(.*)/
            case $1
            when "datatype"
              @queryconditions[qnum]="datatype=#{types_str}" 
              session[:qcond_selection][qnum]=1
              params["query#{qnum+1}"]="datatype=#{types_str}"
              flag=1
            else
              @queryconditions[qnum]=q
              if session[:qcond_selection][qnum]== 1 then
                #params["query#{qnum+1}"]=q
                params["query#{qcond+1}"]=q
                qcond += 1
              end
            end
          end
          qnum += 1
        } 
        
        if flag==0 then #first datatype search
          @queryconditions.push("datatype=#{types_str}")
          #  qnum += 1 
          # params["query#{qnum+1}"]="datatype=#{types_str}"
          params["query#{qcond+1}"]="datatype=#{types_str}"
         session[:qcond_selection][qnum]=1
        else
        
          qnum = qnum - 1 
        end
       
        session[:results]=@results
        params[:nofquery]=qcond+1
        session[:qcno]=qnum+1
        #params[:nofquery]=qnum+1
        #session[:qcno]=qnum+1
      else #���������������Ȃ����
        
        i=1 
        session[:qcond_selection][i-1]=1
        params["query#{i}"]="datatype=#{types_str}"
        @queryconditions.push("datatype=#{types_str}")
        # session[:results]=@results
        params[:nofquery]=i
        session[:queryconditions]=@queryconditions
        session[:qcno]=i
       
      end
      p "query number=#{params[:nofquery]},#{session[:qcno]}"
      cross_search
      show_result
    end
  end
end
 

=begin
###�����l�̎擾###  
   def get_keyvalues(doc,servername)
    # @result_at_server=ResultAtServer.new(0)
    keyvalue= Hash.new
    
    doc=REXML::Document.new(doc)	
    doc.elements.each("//keyword") do  |e|	   
      # str=e.elements["keyname"].text
      e.elements.each("keyvalues/keyvalue") do |f|
        # if e.elements["keyname"].text == str then	
        str1=f.elements["keyvalue"].text
        str2=f.elements["count"].text
        keyvalue.store("#{str1}","#{str2}")
        
      end
      @result_at_server.keyvalue.push(keyvalue) 
          
      @serverlist["#{servername}"]=@result_at_server   
     
      return  @serverlist
    end
  end
=end
