require File.dirname(__FILE__) + '/../test_helper'
require 'webservice_analysis_controller'

class WebserviceAnalysisController; def rescue_action(e) raise e end; end

class WebserviceAnalysisControllerApiTest < Test::Unit::TestCase
  def setup
    @controller = WebserviceAnalysisController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end
end
