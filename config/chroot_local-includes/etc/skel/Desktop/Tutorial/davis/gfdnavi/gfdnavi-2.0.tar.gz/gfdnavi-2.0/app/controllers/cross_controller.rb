#!/usr/bin/ruby
#require "rdb_concat"
require 'rubygems'
require 'open-uri'
#require 'hpricot'
require "rexml/document"
require 'kconv'

class CrossController < ApplicationController 
  layout "gfdnavi"
  
  def index 
    $sflag=0 
    $size=0
    $pcflag=0
    $pflag=0
    $nflag=0
    $kflag=0
    $servers=Array.new()  
    $server=Array.new()
    $query=""
    $count=0
    $p=Array.new(0)
    $pb=Array.new(0)
    session[:previd]=nil
    @previd=nil
    @qargs=nil
    @results=CrossResult.new(0)
    @queryconditions=Array.new
    session[:results]=@results
    session[:qsetid]=1
    session[:queryconditions]=@queryconditions
    session[:qcond_selection]=Array.new
    session[:server_selection]=Array.new
    session[:qcno]=0
    session[:svno]=0
   
    @keyvalues=CrossArray.new(0)
    
    session[:keyvalue]=@keyvalues
  end
  
  def add_keyname
    @results=session[:results]
    @results.keynames.push(params[:keyname])
    @results.keynames.uniq!
    
    session[:results]=@results
    valuelist=@results.get_keyvalue_list(params[:keyname])
    @keyvalues=session[:keyvalue]
    if valuelist.size>0 then
      render :update do |page|
        if($server!=nil&&$sflag==1) then
          for i in 0..@keyvalues.name.size.to_i
            if @keyvalues.name[i]==params[:keyname] then
              page.insert_html(:bottom,"kw_#{params[:keyname]}","<li>#{link_to_remote(@keyvalues.keyvalue[i],{:url=>{:controller=>"cross",:action=>'cross_kw',:keyname=>params[:keyname],:keyvalue=>@keyvalues.keyvalue[i]}})}(#{@keyvalues.cnt[i]})</li>")
            end
          end	
	else
          valuelist.each{|v|	
            page.insert_html(:bottom,"kw_#{params[:keyname]}","<li>#{link_to_remote(v.value,{:url=>{:controller=>"cross",:action=>'cross_kw',:keyname=>params[:keyname],:keyvalue=>v.value}})}(#{v.cnt})</li>")
          }
          
        end
        page.show("kw_#{params[:keyname]}_close")       
      end
    end     
    
  end
  
  def del_keyname
    @results=session[:results]
    @results.keynames.delete(params[:keyname])
    session[:results]=@results
    render :update do |page|
      page.replace_html("kw_#{params[:keyname]}","")
      page.hide("kw_#{params[:keyname]}_close")
    end
  end
  
  def check_box
    l=params[:id].to_i
    if session[:server_selection][l]==1 then
      session[:server_selection][l]=0
      session[:svno]=session[:svno]-1
     
	
    else
      session[:server_selection][l]=1
      session[:svno]=session[:svno]+1
      
      
    end
    
    cnt=0
    #�T�[�o�̑I��
    for i in 0..$servers.size
      if session[:server_selection][i]==1 then
	$server[cnt]=$servers[i]
      else
      end
      cnt=cnt+1
    end
  end
  
  def query_join(desc)
    $count=$count+1
    i=1
    if $count > 1 then
      while i< $count
        params["query#{i}"]=$p[i]
        i = i+1
      end
    end
    params[:nofquery]=$count
    params["query#{i}"]=desc
    $p[i]=desc
    $pb.push(desc)
    @queryconditions=session[:queryconditions]
    @queryconditions.push(desc)
    session[:qcond_selection].push(1)
    session[:qcno]=session[:qcno]+1
    cross_search()
  end

  def cross_search()
    @lat=Array.new()
    @lon=Array.new()
    @pcnt=Array.new()
    @lat_lb=Array.new()
    @lon_lb=Array.new()
    @lat_rt=Array.new()
    @lon_rt=Array.new()
    @cnt=Array.new()
    @kw= Array.new()
    @kcnt=Array.new()
    @nam=Array.new()
    @tit=Array.new()
    @desc=Array.new()
    @path=Array.new()
    
    $query=""
    i=1
    @keyvalues=CrossArray.new(nil)
    @point=Array.new()
    @keyword=Array.new()
    @server=Array.new()
    
    #�������Ȃ��Ă���
    while i <= $count
    
      $query += params["query#{i}"].to_s
	  
	if $count > 1 && i != $count then
		$query += "&"
	  end
	  i = i+1
    end 
    
    params["show_kwfacets"]=1
    params["show_kwvalues"]=0
    params["show_spfacets"]=1
    xmlString=categorized_search()
    
    if $server==Array.new(0) then
      doc=xmlString.to_xml
      get_results(doc)
    else
      $sflag=1
      $query = CGI.escape($query)
      $server.each{ |s|	
        url = "http://#{s}/data/find(#{$query}).xml?show_kwfacets=1&show_spfacets=1"
        kwurl = "http://#{s}/data/find(#{$query}).xml?show_kwfacets=1&show_spfacets=0&show_kwvalues=1"
        
        #	  url = URI.escape(url)
        #	  kwurl = URI.escape(kwurl) 
        begin
          doc = open(url).read.toutf8 
          kwdoc = open(kwurl).read.toutf8
          
          get_results(doc)   
          get_keyvalues(kwdoc)
        rescue
          
        end
      }
    end
    #display
    show_result
  end
  
  def show_result
    render :update do |page| 	  
      
      #/*QueryConditions*/
      i=0
      page.replace_html "qcond","<ul style=\"width:200px;\">"
      page.insert_html :top,"qcond","#{form_remote_tag({:url=>{:action=>'queryconditions_selection'}})}"
      @queryconditions.each{ |q|
	if session[:qcond_selection][i]==1 then 
          page.insert_html :bottom,"qcond", "<li style=\"font-size:13px;\"><input type=\"checkbox\" name=\"qcond_selection_#{i}\" value=\"1\" checked>#{q}</li>"    
	else
          page.insert_html :bottom,"qcond", "<li style=\"font-size:13px;\"><input type=\"checkbox\" name=\"qcond_selection_#{i}\" value=\1\">#{q}</li>"      
	end
	i=i+1
      }
      page.insert_html :bottom,"qcond"," <center><submit_tag(\"selection\")></center>"
      
      
      #/*Keyword*/
      i=0
      page.replace_html "keyword",""
      @kw.each{ |k|
	page.insert_html :bottom,"keyword" , "<ul><li id=\"#{k}\"></li><ul id=\"kw_#{k}\"></ul><div id=\"kw_#{k}_close\" style=\"display:none\">#{link_to_remote("[CLOSE]",{:url=>{:action=>'del_keyname',:keyname=>k}})}</div></ul>" 
	page.replace_html "#{k}","#{link_to_remote(k,{:url=>{:controller=>"cross",:action=>'add_keyname',:keyname=>k}})}(#{@kcnt[i]})"	
        #page.replace_html("kw_#{k}","")
        page.hide("kw_#{k}_close")
	i=i+1
      }
      
      #/*partial_covered*/
      i=0
      page.replace_html "partial_covered",""
      @lon_lb.each{ |p|
	page.insert_html :bottom,"partial_covered","<div id=\"group_#{i}\"></div>"
 	page.replace_html "group_#{i}",  "(<span id=\"lontitude_lb\">#{p}</span>,<span id=\"latitude_lb\">#{@lat_lb[i]}</span>)-(<span id=\"lontitude_rt\">#{@lon_rt[i]}</span>,<span id=\"latitude_rt\">#{@lat_rt[i]}</span>) [#{@cnt[i]}]"
	i=i+1
      }

      #/*point*/
      i=0
      page.replace_html "box","<input type=\"checkbox\" name=\"points\" onclick=\"show_points(this);\" checked> point"
      page.replace_html "points",""
      @lon.each{ |p|
	page.insert_html :bottom,"points","<div id=\"group_#{i}\"></div>"	
	page.replace_html "group_#{i}", "(<span id=\"lontitude\">#{p}</span>,<span id=\"latitude\">#{@lat[i]}</span>) [#{@pcnt[i]}]"
        i=i+1
      }
      
      #/*Result*/
      i=0
      $analviz_tag = image_tag('tree/anal_viz.png', :alt=>'Anal/Vis',
                               :title=>'Analyze/visualize variables in this folder',
                               :border=>0,:align=>'absmiddle')
$details = image_tag('tree/details.png',:alt=>'details', :title=>'Show details',:border=>0,:align=>'absmiddle')
      
      page.replace_html "results",""
      @path.each{|p|
        page.insert_html :bottom,"results","#{p} <br>&nbsp;#{link_to($analviz_tag, :controller=>"finder", :action => "add_to_list", :path => p, :type => @type)}&nbsp;<a href=\"#{data_url(:path => p, :format => "html")}\">#{$details}</a> #{@nam[i]} #{@tit[i]} #{@desc[i]}<br><br>"
        i=i+1
      }
      
      
      #/*map*/
      page << "init();"
      
    end
  end
  
  def categorized_search
    descriptions=Array.new
    if params[:nofquery]!=nil then
      for i in 1..params[:nofquery].to_i do
        if params["query#{i}"]!=nil then
          descriptions.push(params["query#{i}"])
	end
      end
    end
    options=Hash.new
    if params["show_kwfacets"] then
      options["show_kwfacets"]=params["show_kwfacets"]
    else
      options["show_kwfacets"]=0   
    end
    if params["show_spfacets"] then
      options["show_spfacets"]=params["show_spfacets"]
    else
      options["show_spfacets"]=0   
    end
    if params["show_kwvalues"] then
      options["show_kwvalues"]=params["show_kwvalues"]
    else
      options["show_kwvalues"]=0   
    end
    user = (login=session[:user]) && User.find_by_login(login)
    eq=NodeQuery.new
    qstr = eq.make_query(descriptions,user)
    rnodes=Node.find_by_sql(qstr)
    expres=ExplorerResult.new(-1)
    expres.put_results(rnodes)
    session[:results]=expres   
    
    
    return eq.generate_results(rnodes,expres,options)
  end
  
  def get_results(xmlString)
    scnt=0
    #caetgorized_results���猋�ʂ��󂯎��(DOM����)
    @qsetid=session[:qsetid]
    @results=CrossResult.new(@qsetid)
    doc = REXML::Document.new(xmlString)
    
    #point
    xpath = "//point" 
    l=0
    doc.elements.each(xpath) do |e|
      str1=e.elements["latitude-lb"] 
      str2=e.elements["longitude-lb"] 
      str3=e.elements["count"]
      array=str1.text
      array2=str2.text
      array3=str3.text
      
      for i in 0..$psize.to_i
        if  @lat[i]==array && @lon[i]==array2 
          @pcnt[i] = @pcnt[i].to_i + array3.to_i
          $pflag=1
          break
        end
      end
      if $pflag != 1
        @lat.push(array)	
        @lon.push(array2)
        @pcnt.push(array3)	
      end
      @point.push([@lat[l],@lon[l],@pcnt[l]]) 	
      l=l+1
      $pflag=0
    end
    $psize=@lat.size
    
    #partial_covered
    xpath = "//partial-covered/partial-covered" 
    doc.elements.each(xpath) do |e|
      str1=e.elements["latitude-lb"] 
      str2=e.elements["longitude-lb"] 	
      array=str1.text
      array2=str2.text
      str1=e.elements["latitude-rt"]
      str2=e.elements["longitude-rt"]
      array3=str1.text
      array4=str2.text
      str3=e.elements["count"]
      array5=str3.text
      for i in 0..$pcsize.to_i
        if  @lat_lb[i]==array &&@lon_lb[i]==array2 && @lat_rt[i]==array3 && @lon_rt[i]==array4
          @cnt[i] = @cnt[i].to_i + array5.to_i
          $pcflag=1
          break
        end
      end
      if $pcflag != 1
        @lat_lb.push(array)
        @lon_lb.push(array2)	
        @lat_rt.push(array3)
        @lon_rt.push(array4)	
        @cnt.push(array5)
      end
      $pcflag=0	
    end
    $pcsize=@lat_lb.size
    
    #keyword
    l=0
    xpath = "//keyword" 
    doc.elements.each(xpath) do |e|
      str1=e.elements["keyname"] 
      str2=e.elements["count"] 
      array=str1.text
      array2=str2.text
      for i in 0..$ksize.to_i
        if  @kw[i]==array
          @kcnt[i] = @kcnt[i].to_i + array2.to_i
          $kflag=1
          break
        end
      end
      if $kflag != 1
        @kw.push(array)
        @kcnt.push(array2)
      end
      @keyword.push([@kw[l],@kcnt[l]]) 
      l=l+1
      $kflag=0
    end
    $ksize=@kw.size
    #@server.push([@point,@keyword])
    
    #node
    xpath="//node"
    doc.elements.each(xpath) do |e|
      str1=e.elements["name"]
      str2=e.elements["title"]
      array=str1.text
      array2=str2.text
      
      str1=e.elements["description"]
      str2=e.elements["path"]
      array3=str1.text
      array4=str2.text
      for i in 0..$nsize.to_i
        if  @nam[i]==array && @tit[i]==array2 && @desc[i]==array3 && @path[i]==array4
          $nflag=1
          break
        end
      end
      if $nflag != 1
        @nam.push(array)
        @tit.push(array2)
        @desc.push(array3)
        @path.push(array4)
      end
      $nflag=0
    end
    $nsize=@nam.size
    scnt+=1
  end
  
  def get_keyvalues(doc)
    @keyname=Array.new(0)
    doc=REXML::Document.new(doc)	
    doc.elements.each("//keyword") do  |e|	   
      str=e.elements["keyname"].text
      e.elements.each("keyvalues/keyvalue") do |f|
        if e.elements["keyname"].text == str then	
          str1=f.elements["keyvalue"].text
          str2=f.elements["count"].text
          @keyvalues.name.push(str)				 
          @keyvalues.keyvalue.push(str1)
          @keyvalues.cnt.push(str2)        					 
          keyword = Struct.new(:name,:value,:cnt)	
          #  keyname = str
          #@keyname=keyword.new(str,str1,str2)	
          #@keyname.push(keyword.new(str,str1,str2))
        end 
      end
    end
    session[:keyvalue]=@keyvalues
  end
  
  
  def display
    render :action=>"_result.rhtml"
  end

  def cross_kw
    desc="kw.#{params[:keyname]}=#{params[:keyvalue]}"
    query_join(desc)
  end
  
  def cross_freeword 
    desc="fw=#{params[:freeword]}"
    query_join(desc)
  end
  
  def cross_space
    desc="sp.overlap[#{params[:start_lon]},#{params[:start_lat]},#{params[:end_lon]},#{params[:end_lat]}]"
    query_join(desc)
  end
  
  def cross_time
    desc="tm=[#{params[:starttime]},#{params[:endtime]}]"
    query_join(desc)
  end
  
  def queryconditions_selection
    num=0
    k=0
    for i in 0..session[:qcno].to_i-1
      if params["qcond_selection_#{i}"]=="1" then
        session[:qcond_selection][i]=1
	params["query#{num+1}"]=$pb[k]
	$p[num+1]=$pb[k]
	
	num=num+1
      else
        session[:qcond_selection][i]=0
        $p[num]=0
      end
      k=k+1
    end
    $p[num+1]=0
    if num==0 then
      redirect_to :action=>"index"
    else 
      params[:nofquery]=num
      $count=num
      @queryconditions=session[:queryconditions]
      cross_search()  
    end
 end
  
  def get_servers
    # url = GFDNAVI_CROSS_SEARCH_CENTER_SERVER
    url="http://localhost:3010/display/server_list" 
    serv = open(url).read.toutf8
    serv = REXML::Document.new(serv)
    i=0
    xpath = "servers/server"
    serv.elements.each(xpath) do |e|    
      str1=e.elements["name"] 
      str2=e.elements["id"]
      str3=e.elements["url"]
      array=str1.text
      array2=str2.text 
      array3=str3.text
      $servers[i]=array3
      i=i+1
    end
    session[:previd]=nil
    #@server=Array.new
    @previd=nil
    @qargs=nil
    @results=CrossResult.new(0)
    @queryconditions=Array.new
    session[:results]=@results
    session[:qsetid]=1
    session[:queryconditions]=@queryconditions
    session[:qcond_selection]=Array.new
    session[:server_selection]=Array.new
    session[:qcno]=0
    session[:svno]=0
 
    i=0
    render :update do |page| 	
      $servers.each{|s|
        page.insert_html :bottom,"servers","<li style=\"font-size:13px;\">#{check_box_tag("server_selection_#{i}",value="1",checked=false)}
#{observe_field "server_selection_#{i}",  
                        :url=>{:action=>'check_box',:id=>i}}#{s}"
        i=i+1
      }
    end
  end
    
    def nodetype_selection
      num=0
      types=Array.new
      @nodetypes=Hash.new
      ntypes=["data","knowledge","function","draw_method"]
      ntypes.each{ |nt|
        value=params["nodetype_#{nt}"]
        #	puts nt
        if value then
          if params["nodetype_#{nt}"]=="1" then
            types.push(nt)
            num=num+1
            @nodetypes[nt]=1
          else
            @nodetypes[nt]=0
          end
        else
          @nodetypes[nt]=0
        end
      }
      if num==0 then
        redirect_to :action=>"index"
      else
        types_str=types.join(",") 
        if session[:queryconditions] then
          @queryconditions=session[:queryconditions]  
          @queryconditions.push("datatype=#{types_str}")
        end
        
        i=1
	$pb.each { |p|
          params["query#{i}"]=$pb[i-1]
          i=i+1
	}
        session[:qcond_selection][i-1]=1
	params["query#{i}"]="datatype=#{types_str}"
        session[:results]=@results
        params[:nofquery]=i
        $count=i
	cross_search()  
      end
    end
  end
