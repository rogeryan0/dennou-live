require File.dirname(__FILE__) + '/../test_helper'

class SignUpUserTest < Test::Unit::TestCase
  fixtures :sign_up_users

  def setup
    @user = SignUpUser.find(1)
  end

  def test_create
    dave = sign_up_users(:dave)
    assert_kind_of SignUpUser, @user
    assert_equal dave.id, @user.id
    assert_equal dave.login, @user.login
    assert_equal dave.full_name, @user.full_name
    assert_equal dave.email_address, @user.email_address
    assert_equal dave.affiliation, @user.affiliation
    assert_equal dave.password, @user.password
  end
end
