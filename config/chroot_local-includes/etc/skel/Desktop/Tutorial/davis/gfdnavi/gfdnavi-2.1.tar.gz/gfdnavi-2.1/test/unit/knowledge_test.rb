require File.dirname(__FILE__) + '/../test_helper'

class KnowledgeTest < Test::Unit::TestCase
  fixtures :nodes, :knowledges

  def setup
  end

  def test_assert
    assert true
  end

end
