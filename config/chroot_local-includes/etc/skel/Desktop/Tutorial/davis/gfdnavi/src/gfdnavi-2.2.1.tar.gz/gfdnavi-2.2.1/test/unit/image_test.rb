require File.dirname(__FILE__) + '/../test_helper'

class ImageTest < ActiveSupport::TestCase
  fixtures :nodes, :images

  def setup
  end

  def test_assert
    assert true
  end

end
