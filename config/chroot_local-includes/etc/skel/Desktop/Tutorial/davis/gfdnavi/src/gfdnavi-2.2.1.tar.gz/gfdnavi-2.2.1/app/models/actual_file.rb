class ActualFile < ActiveRecord::Base
  belongs_to :variable
end
