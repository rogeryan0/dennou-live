class FunctionArgument < ActiveRecord::Base
  belongs_to :function
  belongs_to :value_type
  acts_as_list :scope => :function
  validates_presence_of :value_type_id
end
