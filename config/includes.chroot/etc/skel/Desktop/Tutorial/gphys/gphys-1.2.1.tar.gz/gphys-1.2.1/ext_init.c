void
Init_gphys_ext()
{
    init_ext_coord();
    init_gphys_interpo();
    init_gphys_multibitIO();
}
