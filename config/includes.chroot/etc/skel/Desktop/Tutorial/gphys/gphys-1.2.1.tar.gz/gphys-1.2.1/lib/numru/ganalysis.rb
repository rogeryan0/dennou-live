require "numru/gphys"

require "numru/ganalysis/covariance"
require "numru/ganalysis/eof"
require "numru/ganalysis/histogram"
require "numru/ganalysis/planet"
require "numru/ganalysis/met"
