require "numru/gfdnavi_data/base"

module NumRu::GfdnaviData
  class Image < NumRu::GfdnaviData::Base
  end
end
