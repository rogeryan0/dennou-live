require "numru/gfdnavi_data/function"

module NumRu::GfdnaviData
  class FunctionLocal < NumRu::GfdnaviData::Function

    OBJECT_CLASS = ::Function

  end
end
