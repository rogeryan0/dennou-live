require "numru/gfdnavi_data/directory"

module NumRu::GfdnaviData
  class DirectoryRemote < NumRu::GfdnaviData::Directory

  end
end
