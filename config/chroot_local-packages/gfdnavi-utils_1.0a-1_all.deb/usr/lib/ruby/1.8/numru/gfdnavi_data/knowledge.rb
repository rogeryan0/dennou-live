require "numru/gfdnavi_data/base"

module NumRu::GfdnaviData
  class Knowledge < NumRu::GfdnaviData::Base


  end
end
