require "numru/gfdnavi_data/draw_method"

module NumRu::GfdnaviData
  class DrawMethodLocal < NumRu::GfdnaviData::DrawMethod

    OBJECT_CLASS = ::DrawMethod

  end
end
