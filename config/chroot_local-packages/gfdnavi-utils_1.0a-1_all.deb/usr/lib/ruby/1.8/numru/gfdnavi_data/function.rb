require "numru/gfdnavi_data/base"

module NumRu::GfdnaviData
  class Function < NumRu::GfdnaviData::Base
  end
end
