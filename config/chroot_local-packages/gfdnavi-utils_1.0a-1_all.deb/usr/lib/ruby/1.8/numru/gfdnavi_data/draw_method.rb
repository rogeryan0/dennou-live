require "numru/gfdnavi_data/base"

module NumRu::GfdnaviData
  class DrawMethod < NumRu::GfdnaviData::Base
  end
end
