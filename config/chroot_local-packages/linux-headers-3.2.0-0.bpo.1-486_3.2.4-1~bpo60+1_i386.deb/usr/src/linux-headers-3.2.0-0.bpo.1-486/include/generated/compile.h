/* This file is auto generated, version 1 */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 Sat Feb 11 14:07:55 UTC 2012"
#define LINUX_COMPILE_DISTRIBUTION "Debian"
#define LINUX_COMPILE_DISTRIBUTION_OFFICIAL_BUILD
#define LINUX_COMPILE_DISTRIBUTION_UPLOADER "ben@decadent.org.uk"
#define LINUX_COMPILE_DISTRIBUTION_VERSION "3.2.4-1~bpo60+1"
#define LINUX_COMPILE_BY "unknown"
#define LINUX_COMPILE_HOST "Debian"
#define LINUX_COMPILER "gcc version 4.4.5 (Debian 4.4.5-8) "
