
module RD
  PACKAGE_VERSION = "0.6.21"
end
