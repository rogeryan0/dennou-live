#ifndef _LINUX_STRING_H_
#define _LINUX_STRING_H_

/* We don't want strings.h stuff being used by user stuff by accident */

#include <string.h>
#endif /* _LINUX_STRING_H_ */
