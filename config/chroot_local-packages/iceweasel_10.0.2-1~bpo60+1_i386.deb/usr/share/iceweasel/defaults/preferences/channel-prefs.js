//@line 2 "/tmp/buildd/iceweasel-10.0.2/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
