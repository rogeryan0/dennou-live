//@line 36 "/tmp/buildd/iceweasel-10.0.2/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/tmp/buildd/iceweasel-10.0.2/browser/locales/en-US/firefox-l10n.js"

