pref("startup.homepage_override_url","");
pref("startup.homepage_welcome_url","");
pref("app.releaseNotesURL", "http://mozilla.debian.net/%LOCALE%/%APP%/%VERSION%/releasenotes/");
